<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <header class="entry-header">
                        <h1 class="entry-title">Lecture <?php echo e(array_get($class[1],'lecture')); ?></h1>   
                        <div class="ratings flex justify-content-center align-items-center">
                        </div><!-- .ratings -->
                    </header><!-- .entry-header -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
</div><!-- .page-header -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="breadcrumbs">
                <ul class="flex flex-wrap align-items-center p-0 m-0">
                    <li><a href="/"><i class="fa fa-home"></i>Home</a></li>
                    <li><a href="/Class">Classes</a></li>
                    <li><a href="<?php echo e(action("ClassController@show",['id'=>$class[0]->class_ID])); ?>"><?php echo e($class[0]->class_name); ?></a></li>
                    <li>Lecture <?php echo e(array_get($class[1],'lecture')); ?></li>
                </ul>
            </div><!-- .breadcrumbs -->
        </div><!-- .col -->
    </div><!-- .row -->
</div><!-- .container -->
<center>
<br>
<h1 style="text-shadow: 5px 5px 5px grey; text-align:center"><?php echo e($class[0]->class_name); ?></h1>    
<br>
<br>
<div>
    <iframe width="420" height="315" src="https://www.youtube.com/embed/<?php echo e(array_get($class[1],'youtubeID')); ?>">></iframe>
</div>
</center>
<br>
<div class="container">
    <h1 style="text-shadow: 5px 5px 5px grey">Description</h1>
    <p><?php echo array_get($class[1],'youtubedesc'); ?></p>
</div>
<br>
<button></button>

<?php if(!Auth::guest()): ?>
    <?php if(Auth::user()->id == 1): ?>
        <br><br>
        <button style="background-color:white; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/learn/<?php echo e($learn->id); ?>/edit"><i class="fa fa-edit"></i> Edit</a></button>
        <?php echo Form::open(['action' => ['learnController@destroy', $learn->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

    <?php endif; ?>
<?php endif; ?>
<br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>