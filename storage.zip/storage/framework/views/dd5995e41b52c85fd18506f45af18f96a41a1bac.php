<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/exercise"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Edit Exercise</h1>
    <br>
        <?php echo Form::open(['action' => ['ExerciseController@update', $exercise->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <h3> Techniques :</h3>
                <p><?php echo $exercise->techniques; ?></p>
            </div>
            <div class="form-group">
                <h3> Question :</h3>
                <p><?php echo $exercise->question; ?></p>
                <br>
            </div>
            <div class="form-group">                
                <?php echo e(Form::label('questiondesc', 'Question Description')); ?>

                <?php echo e(Form::textarea('questiondesc', $exercise->questiondesc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Description'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('qurl', 'Question URL')); ?>

                    <?php echo e(Form::text('qurl', $exercise->qurl, ['class' => 'form-control', 'placeholder' => 'URL'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('ansA', 'Answer Description For A')); ?>

                    <?php echo e(Form::text('ansA', $exercise->ansA, ['class' => 'form-control', 'placeholder' => 'Answer'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('ansB', 'Answer Description For B')); ?>

                    <?php echo e(Form::text('ansB', $exercise->ansB, ['class' => 'form-control', 'placeholder' => 'Answer'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('ansC', 'Answer Description For C')); ?>

                    <?php echo e(Form::text('ansC', $exercise->ansC, ['class' => 'form-control', 'placeholder' => 'Answer'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('ansD', 'Answer Description For D')); ?>

                    <?php echo e(Form::text('ansD', $exercise->ansD, ['class' => 'form-control', 'placeholder' => 'Answer'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('ansE', 'Answer Description For E')); ?>

                    <?php echo e(Form::text('ansE', $exercise->ansE, ['class' => 'form-control', 'placeholder' => 'Answer'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('correctans', 'Correct Answer')); ?>

                    <?php echo e(Form::text('correctans', $exercise->correctans, ['class' => 'form-control', 'placeholder' => 'Correct Answer'])); ?>

            </div>
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

        <br>
        <?php echo Form::open(['action' => ['ExerciseController@destroy', $exercise->id], 'method' => 'POST']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>