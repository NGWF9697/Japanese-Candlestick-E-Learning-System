<?php $__env->startSection('header'); ?>
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Classes Online</p>
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li><a href="/Class">Classes</a></li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25">
                            <?php if($class!='Error'): ?>
                                <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="<?php echo e(action("ClassController@show",['id'=>$post->class_ID])); ?>"><?php echo e($post->class_name); ?></a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="<?php echo e(action("ClassController@search",[$post->created_by])); ?>"><?php echo e($post->created_by); ?> </a></div>

                                            <div class="course-date"><?php echo e($post->created_at->toDateString()); ?></div>
 
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->
                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $ <?php echo e($post->class_price); ?> 
                                        </div><!-- .course-cost -->

                                        <div class="course-ratings flex justify-content-end align-items-center">
                                            
                                        </div><!-- .course-ratings -->
                                    </footer><!-- .entry-footer -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php else: ?>
                                <p>No Match Keyword</p>
                            <?php endif; ?>
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .featured-courses -->
                <div class="pagination flex flex-wrap justify-content-between align-items-center">
                <?php if($class!='Error'): ?>
                    <?php echo e($class->links()); ?>

                <?php endif; ?>
                </div><!-- .pagination -->
            </div><!-- .col -->

            <div class="col-12 col-lg-4">
                <div class="sidebar" style="border:none">
                        <div class="search-widget" style="border-style:solid;border-width:2px;border-color:gray">
                            <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                                <?php echo e(csrf_field()); ?>

                                <input type="search" placeholder="Search..." name="query">
                                <button type="submit" value="search" class="flex justify-content-center align-items-center"><i class="fa fa-search"></i></button>
                            <?php echo Form::close(); ?>

                        </div><!-- .search-widget -->
                        <div class="cat-links">
                                <h2>Class Management</h2>
                                <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                                <ul class="p-0 m-0">
                                    <?php if(!(auth()->user('id')== null)): ?>
                                        <li style="padding-left:17%"><input type="hidden" name="query" value="<?php echo e($user_name = Auth::user()->user_name); ?>"><button type="submit" style="border:none;background:none">My Class</button></li>
                                        <li><a href="<?php echo e(action('ClassController@create')); ?>">Create Class</a></li>
                                        <li><a href="/Class/joinclass">Joined Class</a></li>
                                    <?php else: ?>
                                        <li><a href="/login">Login to view</a></li>
                                    <?php endif; ?>
                                </ul>
                                <?php echo Form::close(); ?>

                        </div><!-- .cat-links -->
    
                        <div class="cat-links">
                            <h2>Categories</h2>
    
                            <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                            <ul class="p-0 m-0">
                                    <?php echo e(csrf_field()); ?>

                                    <li><input type="submit" name="query" value="Single Reversal Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" name="query" value="Double Reversal Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" name="query" value="Triple Reversal Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" name="query" value="Multiple Reversal Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" name="query" value="Double Continuous Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" name="query" value="Multiple Continuous Pattern" style="border:none;background:none"></li>
                                    <li><input type="submit" value="Window" style="border:none;background:none"></li>
                            </ul>
                            <?php echo Form::close(); ?>

                        </div><!-- .cat-links -->
    
                        
                        
    
                        
                    </div><!-- .sidebar -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>