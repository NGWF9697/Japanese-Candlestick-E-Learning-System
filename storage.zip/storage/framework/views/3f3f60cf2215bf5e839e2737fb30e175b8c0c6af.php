<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/cs"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br>
    <h1 style="text-shadow: 5px 5px 5px grey; text-align:center"><?php echo e($cs->title); ?></h1>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Type of Report :</h1>
        <p><?php echo $cs->type; ?></p>
    </div>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Description</h1>
        <p><?php echo $cs->desc; ?></p>
    </div>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Developer Notes</h1>
        <p><?php echo $cs->dev_notes; ?></p>
    </div>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Submited by User Name</h1>
        <p><?php echo $cs->user_name; ?></p>
    </div>
    <br>
    <small style="font-weight:bold">Last Updated on: </small><small> <?php echo e($cs->updated_at); ?></small>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->acc_type == 'Admin'): ?>
            <br><br>
            <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/cs/<?php echo e($cs->id); ?>/edit"><i class="fa fa-edit"></i> Edit</a></button>
            <?php echo Form::open(['action' => ['CSController@destroy', $cs->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
        <?php if(Auth::user()->acc_type != 'Admin'): ?>
            <?php if(Auth::user()->user_name == $cs->user_name): ?>
                <br><br>
                <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/cs/<?php echo e($cs->id); ?>/edit"><i class="fa fa-edit"></i> Edit</a></button>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>