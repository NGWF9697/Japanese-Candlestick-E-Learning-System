<!DOCTYPE html>
<html lang="en">
<head>
    <title>JCS Learning</title>
    
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/elegant-fonts.css')); ?>">
    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/swiper.min.css')); ?>">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">

    <style>
        #black{
            background-color:black;
            color:white;
        }
        #black:hover{
            color:green;
        }
        .active {
            background-color: #4CAF50;
        }
        #right{
            margin-left:5%;
            margin-top:10%;
        }
        #border1{
            border: 2px solid #e1eff4;
            background-color: #f4fcff;
            border-radius: 10px;
            padding: 10px;
        }
        #writing{
            color:grey;
        }
        #writing:hover{
            color:black;
        }
        #bigdiv{
            width:100%;
            height:100%;
            background-image:url('https://paulmampillyguru.com/wp-content/uploads/2017/05/background1-1080x675.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;                       
        }
        #customWord1{
            font-family: "Brush Script MT", serif;
            text-align: center;
            font-size: 40pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord2{
            font-family: "Times New Roman", serif;
            text-align: center;
            font-size: 30pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord3{
            color:black;
            text-align: center;
            padding-top: 5px;
        }
        .form-contain{                        
            border-radius:25px;
            -webkit-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            -moz-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            background-color:whitesmoke;
            padding: 20%;
            margin-top:20%;
            opacity: 0.85;                    
        }
        .form-contain::-webkit-scrollbar{
            display:none
        }
        #hide{
            display:block;
        }        
        .hidden{
            display:none;
        }

        #backgrounds{
            background-image:url(https://willowbendanimal.com/clients/18743/images/about_us_banner.jpg);
        }
        #edit1{
            background-color:  #80b3ff;
            padding: 10px;
        }
        section{
            float:left;
            margin: 0 1.5%;
            width: 10%;
            border:2px solid white;
        }
        aside{
            float:left;
            margin:0 1.5%;
            width:70%;
        }
        #collapse1{
            background-color:white;
        }
        .tabs{
            background-color:black;
            border: 2px solid black;                    
            padding: 15px;
        }
        #tab1{
            background-color:black;
            color:white;
            border-style: transparent;
            font-weight: bold;
            border: none;
            outline: none;
        }
        #tab1:hover{
            color:grey;
            border-style: transparent;
        }
        #tab1:active{
            color:grey;
        }
        .buttonedit{
            background-color: black;
            text-decoration: underline;
            text-decoration-color: white;
            padding: 15px 32px;
            text-align: center;
            color:white;
            font-weight:bold;
            border:none;
        }
        .buttonedit:hover{
            background-color:grey;
        }
        .buttoneditcolor{
            background-color: green;
        }
        .con1{
            border: 2px solid black;
            text-align: left;
            padding: 10px;
            width: 100%;
            height:400px;
            overflow-y:scroll;
        }
        hr{
            background-color:grey;
        }
        @media  screen and (max-width: 500px) {
            #hide{
                float:none;
                display:none;
            }
        }
    </style>
    <script>                                                      
        function openNav() {
            const mq = window.matchMedia( "(min-width: 800px)" );
           
            if (mq.matches){
                // window width is at least 800px
                document.getElementById("mySidenav").style.width = "25%";
                document.getElementById("main-menu").style.width = "25%";
            } else{
                // window width is less than 800px
                document.getElementById("mySidenav").style.width = "80%";
            }
        }
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>

</head>
<body>
    <?php echo $__env->make('inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('header'); ?>
    <br>
    <div class="container" style="box-shadow: 5px 5px 18px; border: 2px solid">        
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
        <?php echo $__env->yieldContent('content'); ?>        
    </div>
    <br>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/d3js/5.7.0/d3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.collapsible.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/masonry.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/add.js')); ?>"></script>
</body>