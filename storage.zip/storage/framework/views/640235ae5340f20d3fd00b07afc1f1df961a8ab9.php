<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/learn"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Create Post</h1>
    <br>
        <?php echo Form::open(['action' => 'learnController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'Title')); ?>

                <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('picurl', 'Picture URL')); ?>

                <?php echo e(Form::text('picurl', '', ['class' => 'form-control', 'placeholder' => 'URL'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('desc', 'Description')); ?>

                <?php echo e(Form::textarea('desc', '', ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('example', 'Example')); ?>

                <?php echo e(Form::textarea('example', '', ['id' => 'ckeditor2', 'class' => 'form-control', 'placeholder' => 'Examples'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>