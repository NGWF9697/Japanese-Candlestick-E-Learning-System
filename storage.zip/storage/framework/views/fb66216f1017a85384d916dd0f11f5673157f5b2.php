<?php $__env->startSection('header'); ?>
    <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
        <div class="container">
            <div class="entry-header" style="text-align:center; padding-top:0;">
                <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Exercises</p>
            </div><!-- .entry-header -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="/exercise"> Exercise</a></li>
            <li style="color:black; font-style:italic">Quiz</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <br>
    <?php echo Form::open(['action' => 'QuizController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <?php if(count($techniques) > 0): ?>
            <?php if(count($techniques) < 10): ?>
                <div class="well">
                    <p>Not Enough Questions, Please contact admin to add more questions</p>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $techniques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="well" style="text-align:center">
                        <h1><?php echo e($technique->question); ?></h1>
                        <?php if($technique->qurl != null): ?>
                            <div>
                                <img src=<?php echo e($technique->qurl); ?> style="width:90%">
                            </div>
                        <?php endif; ?>
                        <br>
                        <h4 style="text-decoration:underline; font-style:italic"><?php echo $technique->questiondesc; ?></h4>
                            <div class="container" style="text-align:left">
                            <?php if($technique->ansA != null): ?>
                                <?php echo e(Form::radio($technique->question, $technique->ansA, ['class' => 'form-control'])); ?> <?php echo e($technique->ansA); ?>

                                <br>
                            <?php endif; ?>
                            <?php if($technique->ansB != null): ?>
                                <?php echo e(Form::radio($technique->question, $technique->ansB, ['class' => 'form-control'])); ?> <?php echo e($technique->ansB); ?>

                                <br>
                            <?php endif; ?>
                            <?php if($technique->ansC != null): ?>
                                <?php echo e(Form::radio($technique->question, $technique->ansC, ['class' => 'form-control'])); ?> <?php echo e($technique->ansC); ?>

                                <br>
                            <?php endif; ?>
                            <?php if($technique->ansD != null): ?>
                                <?php echo e(Form::radio($technique->question, $technique->ansD, ['class' => 'form-control'])); ?> <?php echo e($technique->ansD); ?>

                                <br>
                            <?php endif; ?>
                            <?php if($technique->ansE != null): ?>
                                <?php echo e(Form::radio($technique->question, $technique->ansE, ['class' => 'form-control'])); ?> <?php echo e($technique->ansE); ?>

                                <br>
                            <?php endif; ?>
                            <?php if(!Auth::guest()): ?>
                                <?php if(Auth::user()->acc_type == 'Admin'): ?>
                                    <br><br>
                                    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/exercise/<?php echo e($technique->id); ?>/edit"><i class="fa fa-edit"></i> Edit</a></button>
                                <?php endif; ?>
                        <?php endif; ?>
                        </div>
                        <?php echo e(Form::text($technique->question.$technique->question, $technique->correctans, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::text('name', $technique->techniques, ['class' => 'form-control, hidden'])); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!Auth::guest()): ?>
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="well">
                <p>No exercises found</p>
            </div>
        <?php endif; ?>
    <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>