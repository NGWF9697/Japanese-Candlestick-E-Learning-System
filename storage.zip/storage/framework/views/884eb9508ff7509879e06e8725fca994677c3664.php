<?php $__env->startSection('header'); ?>
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Create Class</p>
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li>Classes</li>
                        <li>Create</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
            <?php echo Form::open(['action' => 'PostsController@store','method' => 'POST','enctype'=>'multipart/form-data']); ?>

                <?php echo e(form::label('text','Class Name :')); ?>

                <input type="text" class="awesome<?php echo e($errors->has('class_name') ? ' is-invalid' : ''); ?>" name="class_name" value="<?php echo e(old('class_name')); ?>" required autofocus>
                <?php if($errors->has('class_name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('class_name')); ?></strong>
                    </span>
                <?php endif; ?>
                    <?php echo e(form::label('Pattern','Category :')); ?>

                    
                    <?php echo e(form::select('class_category',[
                    'Single Reversal Pattern' => 'Single Reversal Pattern',

                    'Double Reversal Pattern' => 'Double Reversal Pattern',

                    'Triple Reversal Pattern' => 'Triple Reversal Pattern',

                    'Multiple Reversal Pattern' => 'Multiple Reversal Pattern',

                    'Double Continuous Pattern' => 'Double Continuous Pattern',

                    'Multiple Continuous Pattern' => 'Multiple Continuous Pattern' ,

                    'Window' =>'Window'
                    ],'',['class' => 'form-group'])); ?>

                    
                    <br>
                    <?php echo e(Form::label('text','Icon For Your Class')); ?>

                    <?php echo e(Form::file('cover_image')); ?>

                    <br>
                    <?php echo e(Form::label('text','What Will Student Learn?')); ?>

                    <textarea class="ckeditor" name="class_learn" cols="50" rows="10"></textarea>
                    <?php echo e(Form::label('text','Description')); ?>

                    <?php echo e(Form::textarea('class_desc','',['class' => 'ckeditor'])); ?>

                    <br>
                    Lecture 1
                    <input type="text" name="youtubelink" class='form-control' placeholder="Please Enter Youtube Link Here">
                    <br>
                    <?php echo e(Form::label('text','Description')); ?>   
                    <textarea class="ckeditor" name="youtubedesc" cols="50" rows="10"></textarea>
                    <div id='lecture1' style="display:none;">
                        <br>
                        Lecture 2
                        <input type="text" name="youtubelink1" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        <?php echo e(Form::label('text','Description')); ?>   
                        <textarea class="ckeditor" name="youtubedesc1" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture2' style="display:none">
                        <br>
                        Lecture 3
                        <input type="text" name="youtubelink2" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        <?php echo e(Form::label('text','Description')); ?>   
                        <textarea class="ckeditor" name="youtubedesc2" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture3' style="display:none">
                        <br>
                        Lecture 4
                        <input type="text" name="youtubelink3" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        <?php echo e(Form::label('text','Description')); ?>   
                        <textarea class="ckeditor" name="youtubedesc3" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture4' style="display:none">
                        <br>
                        Lecture 5
                        <input type="text" name="youtubelink4" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        <?php echo e(Form::label('text','Description')); ?>   
                        <textarea class="ckeditor" name="youtubedesc4" cols="50" rows="10" disabled></textarea>
                    </div>
                    <br>
                    <a id="add" class = "btn">Add more</a>
                    <a id="remove" class = "btn">Remove</a>
                    <br>
                    <br>
                    <input type="submit" class="btn btn-success">
                    <input type="reset" class="btn btn-success">
                <?php echo Form::close(); ?>

            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>