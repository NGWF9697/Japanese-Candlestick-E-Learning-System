<footer class="site-footer">
    <div class="footer-bar" style="background-color:black">
        <div class="container">
            <div class="row flex-wrap justify-content-center justify-content-lg-between align-items-center">
                <div class="col-12 col-lg-6">
                    <div class="download-apps flex flex-wrap justify-content-center justify-content-lg-start align-items-center">
                        <a href="https://www.apple.com/my/"><img src="images/app-store.png" alt=""></a>
                        <a href="https://play.google.com/store"><img src="images/play-store.png" alt=""></a>
                    </div><!-- .download-apps -->

                </div>

                <div class="col-12 col-lg-6 mt-4 mt-lg-0">
                    <div class="footer-bar-nav">
                        <ul class="flex flex-wrap justify-content-center justify-content-lg-end align-items-center">
                        </ul>
                    </div><!-- .footer-bar-nav -->
                </div><!-- .col-12 -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .footer-bar -->
</footer><!-- .site-footer -->