<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/profile" style="background-color:whitesmoke; color:black"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br><br>
    <h3 style="text-shadow: 5px 5px 5px grey; text-align:center"><?php echo e($users->user_name); ?></h3>
    <br>
    <div style="text-align:center">
        <h3 style="text-shadow: 5px 5px 5px grey">Current level : <?php echo e($users->level); ?> </h3>
        <br>        
        <div class="container">
            <div class="w3-border">
                <?php if($users->level == 1): ?>
                    <div class="w3-green" style="height:24px;width:0%"> 0%  </div>
                <?php else: ?>
                    <div class="w3-green" style="height:24px;width:<?php echo e(( $users->xp / floor(($users->level*(log10($users->level))*1000)) )* 100); ?>%"><?php echo e(round($users->xp / floor(($users->level*(log10($users->level))*1000)),5)* 100); ?>%  </div>
                <?php endif; ?>
            </div>
        </div>
        <h3 style="text-shadow: 5px 5px 5px grey">Current xp : <?php echo e($users->xp); ?></h3>
        <br>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Email </h3>
        <p><?php echo e($users->email); ?></p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Age </h3>
        <p><?php echo e($users->age); ?></p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Gender </h3>
        <p><?php echo e($users->gender); ?></p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Token </h3>
        <p><?php echo e($users->token); ?></p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Working Status </h3>
        <p><?php echo e($users->work_status); ?></p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Tutor Pass </h3>
        <p><?php echo e($users->pass); ?></p>
    </div>
    <?php if(Auth::user()->pass != 'Active'): ?>
        <button style="background-color:#008CBA; color:whitesmoke; border:black 2px; border-radius: 10px; margin-left:5%; font-weight:bold; font-size:20px; padding:5px;"><a href="/profile/tutor"><i class="fa fa-male"></i> Tutor</a></button>
    <?php endif; ?>
    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;" class="pull-right"><a href="/profile/edit"><i class="fa fa-edit"></i> Edit</a></button>
    <hr>
    <small style="font-weight:bold">Last Updated on: </small><small> <?php echo e($users->created_at); ?></small>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>