<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/learn"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br>
    <br>
    <h1 id="customWord2">Edit Post</h1>
    <?php echo Form::open(['action' => ['learnController@update', $learn->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title', $learn->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('picurl', 'Picture URL')); ?>

            <?php echo e(Form::text('picurl', $learn->picurl, ['class' => 'form-control', 'placeholder' => 'URL'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('desc', 'Description')); ?>

            <?php echo e(Form::textarea('desc', $learn->desc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('example', 'Example')); ?>

            <?php echo e(Form::textarea('example', $learn->example, ['id' => 'ckeditor2', 'class' => 'form-control', 'placeholder' => 'Examples'])); ?>

        </div>
        <?php echo e(Form::hidden('_method', 'PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>