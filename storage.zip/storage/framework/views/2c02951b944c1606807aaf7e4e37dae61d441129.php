<?php $__env->startSection('header'); ?>
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black"><?php echo e($class[0]->class_name); ?></p>
            <div class="ratings flex justify-content-center align-items-center">
                <input type="hidden" value="<?php echo e($rating = array_get($class[2],'class_avg_rating')); ?>">
                <?php if( $rating > 0 ): ?>
                    <?php for($i = $rating ; $i > 0 ; $i--): ?>
                        <span class="fa fa-star checked"></span>
                    <?php endfor; ?>
                    <?php for($i = 0; $i < 5-$rating  ; $i++): ?>
                        <span class="fa fa-star-o"></span>
                    <?php endfor; ?>
                    <span class="course-ratings" style="font-style:italic; font-size: 25px; font-weight:bold;color:black"><?php echo e($rating); ?></span>
                <?php else: ?>
                    <p> There is no rating </p>
                <?php endif; ?>
            </div><!-- .ratings -->
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="breadcrumbs">
                <ul class="flex flex-wrap align-items-center p-0 m-0">
                    <li><a href="/"><i class="fa fa-home"></i>Home</a></li>
                    <li><a href="/Class">Classes</a></li>
                    <li><?php echo e($class->pluck('class_name')[0]); ?></li>
                </ul>
            </div><!-- .breadcrumbs -->
        </div><!-- .col -->
    </div><!-- .row -->
    <div class="container">
        <div class="row">
            <div class="col-12 offset-lg-1 col-lg-10">
                <div class="featured-image">
                    
                    <img src="/storage/cover_image/<?php echo e($class[0]->cover_image); ?>" alt="noimage.jpg">
                    <div class="course-cost">
                        <div class="free-cost"><i class="fa fa dollar"> $</i><?php echo e($class->pluck('class_price')[0]); ?></div>
                    </div>
                </div>
            </div><!-- .col -->
        </div><!-- .row -->
    </div>
    <div class="row">
        <div class="col-12 offset-lg-1 col-lg-1">
            <div class="post-share">
                <h3>share</h3>

                <ul class="flex flex-wrap align-items-center p-0 m-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-thumb-tack"></i></a></li>
                </ul>
            </div><!-- .post-share -->
        </div><!-- .col -->

        <div class="col-12 col-lg-8">
            <div class="single-course-wrap">
                <div class="course-info flex flex-wrap align-items-center">
                    <div class="course-author flex flex-wrap align-items-center mt-3">
                        
                        
                        <div class="author-wrap">
                            <label class="m-0">Teacher</label>
                            <div class="author-name"><a href="#"><?php echo e($class->pluck('created_by')[0]); ?></a></div>
                        </div><!-- .author-wrap -->
                    </div><!-- .course-author -->

                    <div class="course-cats mt-3">
                        <label class="m-0"><?php echo e($class->pluck('class_category')[0]); ?></label>
                        <div class="author-name"><a href="#">Web design</a></div>
                    </div><!-- .course-cats -->

                    <div class="course-students mt-3">
                        <label class="m-0">Student</label>
                            <input type="hidden" value="
                            <?php echo e($count = DB::table('joinclass')->where('class_id',$class->pluck('class_ID')[0])->count()); ?>">
                            <div class="author-name"><a href="#">
                            <?php if($count>0): ?>
                            <?php echo e($count); ?>

                            (REGISTERED)
                            <?php else: ?>
                            0 (REGISTERED)
                            <?php endif; ?>
                            </a>
                            </div>
                    </div><!-- .course-students -->

                    <div class="buy-course mt-3">
                        <?php if(!array_get($class[3],'Exists')): ?>
                        <?php echo Form::open(['action' => 'ClassController@store','method' => 'POST']); ?>

                            <input type="hidden" name="class_ID" value="<?php echo e($class->pluck('class_ID')[0]); ?>">
                            <input type="hidden" name="user_ID" value="<?php echo e(auth()->user('id')->id); ?>">
                            <button type="submit" style="background:none;border:none"><a class="btn">Join Class</a></button>
                        <?php echo Form::close(); ?>

                        <?php else: ?>
                        <button type="submit" style="border:none;background:none"><a class="btn" href="/Class/lecture/<?php echo e($class->pluck('class_ID')[0]); ?>">Start</a></button>
                        <?php endif; ?>
                    </div><!-- .buy-course -->
                </div><!-- .course-info -->

                <div class="single-course-cont-section">
                    <h2>What Will I Learn?</h2>
                    <ul class="p-0 m-0 green-ticked">
                        <?php if(strpos($class->pluck('class_learn')[0],"\n")!== false): ?>
                            <?php $__currentLoopData = explode("\n",$class->pluck('class_learn')[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $words): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e(strip_tags($words)); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li><?php echo e(strip_tags($class->pluck('class_learn')[0])); ?></li>
                        <?php endif; ?>
                    </ul>
                    <h2>Description</h2>
                    <?php if(strpos($class->pluck('class_desc')[0],"\n")!== false): ?>
                        <?php $__currentLoopData = explode("\r",$class->pluck('class_desc')[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $words): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(strip_tags($words)); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li><?php echo e(strip_tags($class->pluck('class_desc')[0])); ?></li>
                    <?php endif; ?>

                </div>

                <div class="single-course-accordion-cont mt-3">
                    <header class="entry-header flex flex-wrap justify-content-between align-items-center">
                        <h2>Curriculum For This Course</h2>
                        <div class="number-of-lectures"><?php echo e(sizeof($class[1])); ?> Lectures</div>
                        <div class="total-lectures-time"></div>
                    </header><!-- .entry-header -->

                    <div class="entry-contents">
                        <div class="accordion-wrap type-accordion">
                            <h3 class="entry-title flex flex-wrap justify-content-between align-items-lg-center">
                                
                                <span class="lecture-group-title"><?php echo e($class->pluck('class_name')[0]); ?></span>
                                <span class="number-of-lectures"><?php echo e(sizeof($class[1])); ?> Lectures</span>
                                <span class="total-lectures-time"></span>
                            </h3>
                            <div class="ent ry-content">
                                    <ul class="p-0 m-0">
                                        <?php $__currentLoopData = $class[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="flex flex-column flex-lg-row align-items-lg-center"><span class="lecture-title">
                                            <?php echo e(Youtube::getVideoInfo(Youtube::parseVidFromURL($count->youtube_link))->snippet->title); ?></span>
                                            <span class="lectures-preview"></span>
                                            <input type ="hidden" value="<?php echo e($duration =Youtube::getVideoInfo(Youtube::parseVidFromURL($count->youtube_link))->contentDetails->duration); ?>">
                                            <input type ="hidden" value="<?php echo e(preg_match_all('!\d+!', $duration, $format)); ?>">
                                            </span><span class="lectures-time text-left text-lg-right">
                                            <input type ="hidden" value="<?php echo e($minute = $format[0][0]); ?>">
                                            <input type ="hidden" value="<?php echo e($second = $format[0][1]); ?>">
                                            <?php if(strlen((string)$format[0][0])==1): ?>
                                                <input type ="hidden" value="<?php echo e($minute ="0".$minute); ?>">
                                            <?php endif; ?>
                                            <?php if(strlen((string)$format[0][1])==1): ?>
                                                <input type ="hidden" value="<?php echo e($second ="0".$second); ?>">
                                            <?php endif; ?>
                                            <?php echo e($minute); ?>:<?php echo e($second); ?>

                                            </span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                            </div>
                        </div>
                    </div>
                    </div>
                        
                
            </div><!-- .single-course-wrap -->
        </div><!-- .col -->
    </div><!-- .row -->
</div><!-- .container -->

<div class="clients-logo" style="background:none">
    
</div><!-- .clients-logo -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>