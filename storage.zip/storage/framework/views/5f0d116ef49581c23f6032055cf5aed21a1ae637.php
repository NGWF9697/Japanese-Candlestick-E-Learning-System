<footer class="site-footer">
    <div class="footer-widgets" style="background-color:#DFDFDF">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="foot-about">

                        <h2>Legal Disclaimer</h2>
                        <p>The author is not responsible for any contents linked or referred to from this page.</p>

                    </div><!-- .foot-about -->
                </div><!-- .col -->

                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                    <div class="foot-contact">
                        <h2>Contact Us</h2>

                        <ul>
                            <li>Email: jcslearning@gmail.com</li>
                            <li>Phone: (+60) 12 682 3398</li>
                            <li>Address: Persiaran Multimedia, 63100 Cyberjaya, Selangor</li>
                        </ul>
                    </div><!-- .foot-contact -->
                </div><!-- .col -->

                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-lg-0">
                    <div class="quick-links flex flex-wrap">
                        <h2 class="w-100">Quick Links</h2>

                        <ul class="w-50">
                            <li><a href="/about" style="background-color:#DFDFDF">About </a></li>
                            <li><a href="/learn" style="background-color:#DFDFDF">Learn</a></li>
                            <li><a href="/cs/create" style="background-color:#DFDFDF">Customer Service</a></li>
                        </ul>

                        <ul class="w-50">
                            <li><a href="/exercise" style="background-color:#DFDFDF">Exercise</a></li>
                            <li><a href="/classes" style="background-color:#DFDFDF">Classes</a></li>
                            <li><a href="/profile" style="background-color:#DFDFDF">Profile</a></li>
                            <li><a href="/achievement" style="background-color:#DFDFDF">Achievement</a></li>
                        </ul>
                    </div><!-- .quick-links -->
                </div><!-- .col -->

                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-lg-0">
                    <div class="follow-us">
                        <h2>Follow Us</h2>

                        <ul class="follow-us flex flex-wrap align-items-center">
                            <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://plus.google.com/discover"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://twitter.com/login?lang=en"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div><!-- .quick-links -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .footer-widgets -->

    <div class="footer-bar" style="background-color:black">
        <div class="container">
            <div class="row flex-wrap justify-content-center justify-content-lg-between align-items-center">
                <div class="col-12 col-lg-6">
                    <div class="download-apps flex flex-wrap justify-content-center justify-content-lg-start align-items-center">
                        <a href="https://www.apple.com/my/"><img src="images/app-store.png" alt=""></a>
                        <a href="https://play.google.com/store"><img src="images/play-store.png" alt=""></a>
                    </div><!-- .download-apps -->

                </div>

                <div class="col-12 col-lg-6 mt-4 mt-lg-0">
                    <div class="footer-bar-nav">
                        <ul class="flex flex-wrap justify-content-center justify-content-lg-end align-items-center">
                        </ul>
                    </div><!-- .footer-bar-nav -->
                </div><!-- .col-12 -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .footer-bar -->
</footer><!-- .site-footer -->