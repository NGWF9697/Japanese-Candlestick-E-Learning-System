<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div class="page-header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <header class="entry-header">
                            <h1>Detail</h1>
                        </header><!-- .entry-header -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li>Classes</li>
                        <li>Create</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
            <?php echo Form::open(['action' => 'PostsController@store','method' => 'POST']); ?>

                <?php echo e(form::label('text','Class Name :')); ?>

                <input type="text" class="awesome<?php echo e($errors->has('class_name') ? ' is-invalid' : ''); ?>" name="class_name" value="<?php echo e(old('class_name')); ?>" required autofocus>
                <?php if($errors->has('class_name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('class_name')); ?></strong>
                    </span>
                <?php endif; ?>
                    <?php echo e(form::label('Pattern','Category :')); ?>

                    
                    <?php echo e(form::select('class_category',[
                    'Single Reversal Pattern' => ['hammer'=>'Hammer','hanging_man'=>'Hanging Man','inverted_hammer'=>'Inverted Hammer',
                    'shooting_star'=>'Shooting Star','doji_at_the_bottom'=>'Doji At The Bottom','doji_at_the_top'=>'Doji At The Top',
                    'bullish_meeting_line'=>'Bullish Meeting Line','bearish_meeting_line'=>'Bearish Meeting Line',
                    'bullish_belt_hold_line'=>'Bullish Belt Hold Line','bearish_belt_hold_line'=>'Bearish Belt Hold Line'],

                    'Double Reversal Pattern' => ['bullish_engulfing'=>'Bullish Engulfing','bearish_engulfing'=>'Bearish Engulfing',
                    'fred_tam’s_white_inside_out_up'=>'Fred Tam’s White Inside Out Up','fred_tam’s_black_inside_out_down'=>'Fred Tam’s Black Inside Out Down'
                    ,'piercing_line'=>'Piercing Line','dark_cloud_cover'=>'Dark Cloud Cover','bullish_harami_line'=>'Bullish Harami Line',
                    'bearish_harami_line'=>'Bearish Harami Line','bullish_harami_cross'=>'Bullish Harami Cross',
                    'bearish_harami_cross'=>'Bearish Harami Cross','homing_pigeon'=>'Homing Pigeon','bearish_homing_pigeon'=>'Bearish Homing Pigeon',
                    'tweezers_bottom'=>'Tweezers Bottom','tweezers_top'=>'Tweezers Top'],

                    'Triple Reversal Pattern' => ['star_at_the_bottom'=>'Star At The Bottom','star_at_the_top'=>'Star At The Top',
                    'river_morning_doji_star'=> 'River Morning Doji Star','river_evening_doji_star'=>'River Evening Doji Star',
                    'abandon_baby_bottom'=>'Abandon Baby Bottom','abandon_baby_top'=>'AbandonBaby Top',
                    'three-river_evening_star'=>'Three-River Evening Star','three-river_morning_star'=>'Three-River Morning Star',
                    'tri-star_bottom'=>'Tri-Star Bottom','tri-star_top'=>'Tri-Star Top',
                    'breakaway_three_new_price_bottom'=>'Breakaway Three New Price Bottom',
                    'breakaway_three_new_price_top'=>'Breakaway Three New Price Top',
                    'bullish_black_three-gaps'=>'Bullish Black Three-Gaps','bearish_white_three-gaps'=>'Bearish White Three-Gaps',
                    'three_black_crows'=>'Three Black Crows','deliberation'=>'Deliberation','upside_gap_two_crows'=>'Upside Gap Two Crows'],

                    'Multiple Reversal Pattern' =>['concealing_baby_swallow'=>'Concealing Baby Swallow','ladder_bottom'=>'Ladder Bottom',
                    'tower_bottom'=>'Tower Bottom','tower_top'=>'Tower Top',
                    'eight-to-ten_new_price_low'=>'Eight-To-Ten New Price Low','eight-to-ten_new_price_high'=>'Eight-To-Ten New Price High'],

                    'Double Continuous Pattern' =>['bullish_separating_line'=>'Bullish Separating Line',
                    'bearish_separating_line'=>'Bearish Separating Line','bullish_kicking_pattern'=>'Bullish Kicking Pattern',
                    'bearish_kicking_pattern'=>'Bearish Kicking Pattern','on-neck_line'=>'On-Neck Line',
                    'in-neck_line'=>'In-Neck Line','thrusting_line'=>'Thrusting Line'],

                    'Multiple Continuous Pattern' =>['rising_three_methods'=>'Rising Three Methods',
                    'falling_three_method'=>'Falling Three Method','mat_hold_pattern'=>'Mat Hold Pattern'],

                    'Window' =>['tasuki_upside_gap'=>'Tasuki Upside Gap','tasuki_downside_gap'=>'Tasuki Downside Gap',
                    'upgap_side-by-side_white_lines'=>'Upgap Side-By-Side White Lines',
                    'downgap_side-by-side_white_lines'=>'Downgap Side-By-Side White Lines',
                    'high-price_gapping_play'=>'High-Price Gapping Play','low-price_gapping_play'=>'Low-Price Gapping Play']
                    ],['class' => 'form-group'])); ?>

                    
                    <?php echo e(Form::label('text','What Will Student Learn?')); ?>

                    <textarea class="ckeditor" name="class_learn" cols="50" rows="10"></textarea>
                    <?php echo e(Form::label('text','Description')); ?>

                    <?php echo e(Form::textarea('class_desc','',['class' => 'ckeditor'])); ?>

                    <br>
                    Lecture 1
                    <input type="text" name="youtubelink" class='form-control' placeholder="Please Enter Youtube Link Here">
                    <br>
                    <?php echo e(Form::label('text','Description')); ?>   
                    <textarea class="ckeditor" name="youtubedesc" cols="50" rows="10"></textarea>
                    <br>
                    <a id="add" class = "btn" >Add more</a>
                    <br>
                    <div id="container">
                    </div>
                    <br>
                    <input type="submit" class="btn btn-success">
                    <input type="reset" class="btn btn-success">
                <?php echo Form::close(); ?>

            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>