<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Edit Post</h1>
    <br>
        <?php echo Form::open(['action' => ['UpdateController@update', $update->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'Title')); ?>

                <?php echo e(Form::text('title', $update->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('desc', 'Description')); ?>

                <?php echo e(Form::textarea('desc', $update->desc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('type', 'Type')); ?>

                <?php echo e(Form::select('type', array('Recent'=>'Recent', 'Important'=>'Important', 'General'=>'General'), $update->type, ['class' => 'form-control'])); ?>

            </div>
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>