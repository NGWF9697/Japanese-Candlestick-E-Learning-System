<?php $__env->startSection('content'); ?>
    <div class="page-header">

        <div class="page-header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <header class="entry-header">
                            <h1>Classes Online</h1>
                        </header><!-- .entry-header -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li><a href="/Class">Classes</a></li>
                        <li>Joined</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25">
                            <?php if($class == 'error'): ?>
                                <p>You haven join any class</p>
                            <?php else: ?>
                                <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="<?php echo e(action("ClassController@show",['id'=>$post->class_ID])); ?>"><?php echo e($post->class_name); ?></a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="/viewclass/<?php echo e($created_by = $post->created_by); ?>"><?php echo e($post->created_by); ?> </a></div>
                                            <div class="course-date"><?php echo e(explode(' ',$post->created_at)[0]); ?></div>
 
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->
                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $ <?php echo e($post->class_price); ?>

                                        </div><!-- .course-cost -->
                                        <input type="hidden" value="<?php echo e($rated = DB::table("joinclass")->where([
                                            ['class_ID',$post->class_ID],
                                            ['user_id',auth()->user('id')->id]
                                            ])->get()); ?>">

                                        <?php if($rated[0]->rating == 0.0): ?>
                                            <div class="course-ratings flex justify-content-end align-items-center">
                                                <?php echo Form::open(['action' => ['ClassController@update',$post->class_ID],'method'=>'POST']); ?>

                                                    <button type="submit" name="rating" style="background:none;border:none" value="1"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="2"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="3"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="4"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="5"><span class="fa fa-star checked"></span></button>
                                                    <div class="course-thumbnail" style="text-align:center">Click to Rate</div><!-- .course-cost -->
                                                <?php echo Form::hidden('_method','PUT'); ?>

                                                <?php echo Form::close(); ?>

                                            </div><!-- .course-ratings -->
                                        <?php else: ?>
                                            <div class="course-ratings flex justify-content-end align-items-center">
                                                <input type="hidden" value="<?php echo e($rating = DB::table('joinclass')
                                                                ->where('class_ID',$post->class_ID)
                                                                ->select(DB::raw('AVG(rating) as avg_rating'))
                                                                ->get()); ?>">
                                                <?php for($i = round($rating[0]->avg_rating) ; $i > 0 ; $i--): ?>
                                                    <span class="fa fa-star checked"></span>
                                                <?php endfor; ?>
                                                <?php for($i = 0; $i < 5-round($rating[0]->avg_rating)  ; $i++): ?>
                                                    <span class="fa fa-star-o"></span>
                                                <?php endfor; ?>
                                                <span class="course-ratings"><?php echo e(round($rating[0]->avg_rating)); ?></span>
                                            </div><!-- .course-ratings -->
                                        <?php endif; ?>
                                    </footer><!-- .entry-footer -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .featured-courses -->
                <div class="pagination flex flex-wrap justify-content-between align-items-center">
                    <?php echo e($class->links()); ?>

                </div><!-- .pagination -->
            </div><!-- .col -->

            <div class="col-12 col-lg-4">
                <div class="sidebar">
                    <div class="search-widget" style="border-style:solid;border-width:2px;border-color:gray">
                        <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                            <?php echo e(csrf_field()); ?>

                            <input type="search" placeholder="Search..." name="query">
                            <button type="submit" value="search" class="flex justify-content-center align-items-center"><i class="fa fa-search"></i></button>
                        <?php echo Form::close(); ?>

                    </div><!-- .search-widget -->
                    <div class="cat-links">
                            <h2>Class Management</h2>
                            <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                            <ul class="p-0 m-0">
                                <?php if(!(auth()->user('id')== null)): ?>
                                    <li><a href="<?php echo e(action('ClassController@myclass')); ?>">My Class</a></li>
                                    <li><a href="<?php echo e(action('ClassController@create')); ?>">Create Class</a></li>
                                    <li><a href="/Class/joinclass" style="background:none !important">Joined Class</a></li>
                                <?php else: ?>
                                    <li><a href="/login">Login to view</a></li>
                                <?php endif; ?>
                            </ul>
                            <?php echo Form::close(); ?>

                    </div><!-- .cat-links -->

                    <div class="cat-links">
                        <h2>Categories</h2>

                        <?php echo Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']); ?>

                        <ul class="p-0 m-0">
                                <?php echo e(csrf_field()); ?>

                                <li><input type="submit" name="query" value="Single Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Triple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" value="Window" style="border:none;background:none"></li>
                        </ul>
                        <?php echo Form::close(); ?>

                    </div><!-- .cat-links -->

                    
                    
                </div><!-- .sidebar -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>