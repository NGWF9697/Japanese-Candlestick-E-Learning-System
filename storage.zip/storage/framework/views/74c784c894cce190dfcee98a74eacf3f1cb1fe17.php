<?php $__env->startSection('header'); ?>
<div id="bigdiv">
    <div class="container-fluid">
        <br>
        <button class="button1"><a href="/"><i class="fa fa-arrow-left"></i> Home </button></a>
        <div class="row justify-content-center">
            <div class="container col-lg-4 col-sm-10">
                <div class="form-contain">
                    <p id="customWord1">Register </p><br>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="user_name" id="customWord2"><?php echo e(__('User Name:')); ?></label>
                                <div style="margin-left:auto; margin-right:auto; width:100%">
                                    <input id="user_name" type="text" class="form-control<?php echo e($errors->has('user_name') ? ' is-invalid' : ''); ?>" name="user_name" value="<?php echo e(old('user_name')); ?>" required autofocus>

                                    <?php if($errors->has('user_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('user_name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" id="customWord2"><?php echo e(__('E-Mail Address:')); ?></label>

                                <div style="margin-left:auto; margin-right:auto; width:100%">
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" id="customWord2"><?php echo e(__('Password:')); ?></label>
                                <div style="margin-left:auto; margin-right:auto; width:100%">
                                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password-confirm" id="customWord2"><?php echo e(__('Confirm Password:')); ?></label>
                                <div style="margin-left:auto; margin-right:auto; width:100%">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <p id="customWord2">Gender : </p>
                            </div>
                            <div class="form-group row">
                                <select name="gender" class="select1">
                                    <option value="Male" class="option1">Male</option>
                                    <option value="Female" class="option1">Female</option>
                                </select>
                            </div>

                            <div class="form-group row">
                                <p id="customWord2">Age : </p>
                            </div>
                            <div class="form-group row">
                                <input name="age" type="integer" placeholder="Age" style="padding:10px">
                            </div>
                            <div class="form-group row">
                                <p id="customWord2">Work Status : </p>
                            </div>
                            <div class="form-group row">
                                <select name="work_status" class="select1">
                                    <option value="Yes" class="option1">Yes</option>
                                    <option value="No" class="option1">No</option>
                                </select>
                            </div>
                            <div style="text-align:center">
                                <a href="/learn">
                                    <button type="submit" class="btn btn-primary" style="font-size:20px;">
                                    <i class="fa fa-check"></i><?php echo e(__('Register')); ?>

                                    </button>
                                </a>
                            </div>
                            <br>
                            <div style="text-align:center">
                                <button style="background-color:white; border:none; margin-left:5%; font-weight:bold; font-size:20px; opacity: 0.85;"><a href="/login" style="font-style:italic;"><i class="fa fa-male" style="font-size:30px"></i>  Old User ? <i class="fa fa-female" style="font-size:30px"></i></a></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>