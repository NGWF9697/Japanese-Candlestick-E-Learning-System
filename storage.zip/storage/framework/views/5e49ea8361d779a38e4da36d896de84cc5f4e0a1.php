<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li style="color:black">Achievement</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <br>    
    <div class="well">
        
        <p style="font-style:italic; color:grey; font-size:20px">Progress 1</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_1 / $progress->total_progress_1*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_1 / $progress->total_progress_1*100); ?>% Completed</div>
        <br>
        <div style="text-align:right">
            <?php if($progress->current_progress_1 / $progress->total_progress_1*100 >= 100): ?>
                <?php if($progress->claimed < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 2</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_2 / $progress->total_progress_2*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_2 / $progress->total_progress_2*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_2 / $progress->total_progress_2*100 >= 100): ?>
                <?php if($progress->claimed >= 1): ?>
                    <?php if($progress->claimed < 2): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 3</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_3 / $progress->total_progress_3*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_3 / $progress->total_progress_3*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_3 / $progress->total_progress_3*100 >= 100): ?>
                <?php if($progress->claimed >= 2): ?>
                    <?php if($progress->claimed < 3): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 4</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_4 / $progress->total_progress_4*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_4 / $progress->total_progress_4*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_4 / $progress->total_progress_4*100 >= 100): ?>
                <?php if($progress->claimed >= 3): ?>
                    <?php if($progress->claimed < 4): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 5</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_5 / $progress->total_progress_5*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_5 / $progress->total_progress_5*100); ?>% Completed</div>
        <div style="text-align:right">
                <?php if($progress->current_progress_5 / $progress->total_progress_5*100 >= 100): ?>
                <?php if($progress->claimed >= 4): ?>
                    <?php if($progress->claimed < 5): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 6</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_6 / $progress->total_progress_6*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_6 / $progress->total_progress_6*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_6 / $progress->total_progress_6*100 >= 100): ?>
                <?php if($progress->claimed >= 5): ?>
                    <?php if($progress->claimed < 6): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 7</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_7 / $progress->total_progress_7*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_7 / $progress->total_progress_7*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_7 / $progress->total_progress_7*100 >= 100): ?>
                <?php if($progress->claimed >= 6): ?>
                    <?php if($progress->claimed < 7): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 8</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_8 / $progress->total_progress_8*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_8 / $progress->total_progress_8*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_8 / $progress->total_progress_8*100 >= 100): ?>
                <?php if($progress->claimed >= 7): ?>
                    <?php if($progress->claimed < 8): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 9</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_9 / $progress->total_progress_9*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_9 / $progress->total_progress_9*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_9 / $progress->total_progress_9*100 >= 100): ?>
                <?php if($progress->claimed >= 8): ?>
                    <?php if($progress->claimed < 9): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:grey; font-size:20px">Progress 10</p>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->current_progress_10 / $progress->total_progress_10*100); ?>%; background-color:#04e01a"></div>
        </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->current_progress_10 / $progress->total_progress_10*100); ?>% Completed</div>
        <div style="text-align:right">
            <?php if($progress->current_progress_10 / $progress->total_progress_10*100 >= 100): ?>
                <?php if($progress->claimed >= 9): ?>
                    <?php if($progress->claimed < 10): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>