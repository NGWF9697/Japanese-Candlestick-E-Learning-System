<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li style="color:black">Achievement</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <br>    
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px; font-weight:bold">Complete 2 Exercises</p>
        <?php if($progress->do_progress_1 <= 2 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->do_progress_1 / 2 *100); ?>%; background-color:#04e01a"></div>
            </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->do_progress_1 / 2 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if($progress->do_progress_1 / 2 *100 >= 100): ?>
                <?php if($progress->claimed1 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed1', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Complete 4 Exercises</p>
        <?php if($progress->do_progress_1 <= 4 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->do_progress_1 / 4 *100); ?>%; background-color:#04e01a"></div>
            </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->do_progress_1 / 4 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if($progress->do_progress_1 / 4 *100 >= 100): ?>
                <?php if($progress->claimed1 >= 1): ?>
                    <?php if($progress->claimed1 < 2): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed1', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Complete 8 Exercises</p>
        <?php if($progress->do_progress_1 <= 8 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->do_progress_1 / 8 *100); ?>%; background-color:#04e01a"></div>
            </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->do_progress_1 / 8 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if($progress->do_progress_1 / 8 *100 >= 100): ?>
                <?php if($progress->claimed1 >= 2): ?>
                    <?php if($progress->claimed1 < 3): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed1', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Complete 10 Exercises</p>
        <?php if($progress->do_progress_1 <= 10 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->do_progress_1 / 10 *100); ?>%; background-color:#04e01a"></div>
            </div>
        <div style="color:black; font-weight:bold"><?php echo e($progress->do_progress_1 / 10 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if($progress->do_progress_1 / 10 *100 >= 100): ?>
                <?php if($progress->claimed1 >= 3): ?>
                    <?php if($progress->claimed1 < 4): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed1', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Complete 20 Exercises</p>
        <?php if($progress->do_progress_1 <= 20 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($progress->do_progress_1 / 20 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e($progress->do_progress_1 / 20 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if($progress->do_progress_1 / 20 *100 >= 100): ?>
                <?php if($progress->claimed1 >= 4): ?>
                    <?php if($progress->claimed1 < 5): ?>
                        <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::number('claimed1', 1, ['class' => 'form-control, hidden'])); ?>

                            <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <p>Claimed</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Reach level 2</p>
        <?php if(Auth::user()->level <= 2 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(Auth::user()->level / 2 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e(Auth::user()->level / 2 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if( Auth::user()->level / 2 *100 >= 100): ?>
                <?php if($progress->claimed2 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed2', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Reach level 4</p>
        <?php if(Auth::user()->level <= 4 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(Auth::user()->level / 4 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e(Auth::user()->level / 4 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if( Auth::user()->level / 4 *100 >= 100): ?>
                <?php if($progress->claimed3 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed3', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Reach level 5</p>
        <?php if(Auth::user()->level <= 5 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(Auth::user()->level / 5 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e(Auth::user()->level / 5 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if( Auth::user()->level / 5 *100 >= 100): ?>
                <?php if($progress->claimed4 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed4', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Reach level 6</p>
        <?php if(Auth::user()->level <= 6 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(Auth::user()->level / 6 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e(Auth::user()->level / 6 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if( Auth::user()->level / 6 *100 >= 100): ?>
                <?php if($progress->claimed5 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed5', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="well">
        <p style="font-style:italic; color:black; font-size:20px">Reach level 10</p>
        <?php if(Auth::user()->level <= 10 ): ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(Auth::user()->level / 10 *100); ?>%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold"><?php echo e(Auth::user()->level / 10 *100); ?>% Completed</div>
        <?php else: ?>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:100%; background-color:#04e01a"></div>
            </div>
            <div style="color:black; font-weight:bold">100% Completed</div>
        <?php endif; ?>
        <div style="text-align:right">
            <?php if( Auth::user()->level / 10 *100 >= 100): ?>
                <?php if($progress->claimed6 < 1): ?>
                    <?php echo Form::open(['action' => 'AchieveController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <?php echo e(Form::number('token', 50, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::number('claimed6', 1, ['class' => 'form-control, hidden'])); ?>

                        <?php echo e(Form::submit('Claim', ['class'=>'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <p>Claimed</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>