<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/cs"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Submit Report or Suggestion</h1>
    <br>
        <?php echo Form::open(['action' => 'CSController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('type', 'Type')); ?>

                <?php echo e(Form::select('type', array('Bug and Errors'=>'Bug and Errors', 'ID/Sign Up'=>'ID/Sign Up', 'Suggestions'=>'Suggestions', 'Report Users'=>'Report Users'), '', ['class' => 'form-control', 'required'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('type', 'Title')); ?>

                <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Add Title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('desc', 'Description')); ?>

                <?php echo e(Form::textarea('desc', 'Add Description as much as possible (You may remove this line)', ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Add Description as much as possible'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::text('dev_notes', 'Reply Pending......', ['class' => 'form-control','hidden'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>