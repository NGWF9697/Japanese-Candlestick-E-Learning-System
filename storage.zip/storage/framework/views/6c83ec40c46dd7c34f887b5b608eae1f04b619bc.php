<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/exercise"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br>
    <h1 style="text-shadow: 5px 5px 5px grey; text-align:center">Question Technique: <?php echo e($result->title); ?></h1>    
    <br>
    <div style="text-align:center">
        <table>
            <tr>
                <th>Question Number</th>
                <th>Attempted Results</th>
            </tr>
            <tr>
                <th> Question 01 </th>
                <th> <?php echo e($result->quest1); ?></th>
            </tr>
            <tr>
                <th> Question 02 </th>
                <th> <?php echo e($result->quest2); ?></th>
            </tr>
            <tr>
                <th> Question 03 </th>
                <th> <?php echo e($result->quest3); ?></th>
            </tr>
            <tr>
                <th> Question 04 </th>
                <th> <?php echo e($result->quest4); ?></th>
            </tr>
            <tr>
                <th> Question 05 </th>
                <th> <?php echo e($result->quest5); ?></th>
            </tr>
            <tr>
                <th> Question 06 </th>
                <th> <?php echo e($result->quest6); ?></th>
            </tr>
            <tr>
                <th> Question 07 </th>
                <th> <?php echo e($result->quest7); ?></th>
            </tr>
            <tr>
                <th> Question 08 </th>
                <th> <?php echo e($result->quest8); ?></th>
            </tr>
            <tr>
                <th> Question 09 </th>
                <th> <?php echo e($result->quest9); ?></th>
            </tr>
            <tr>
                <th> Question 10 </th>
                <th> <?php echo e($result->quest10); ?></th>
            </tr>
        </table>
    </div>
    <br><br>
    <div class="container">
        <h3>Question 01 Choice: </h3><p> <?php echo e($result->quest1desc); ?></p>
        <br>
        <h3>Question 02 Choice: </h3><p> <?php echo e($result->quest2desc); ?></p>
        <br>
        <h3>Question 03 Choice: </h3><p> <?php echo e($result->quest3desc); ?></p>
        <br>
        <h3>Question 04 Choice: </h3><p> <?php echo e($result->quest4desc); ?></p>
        <br>
        <h3>Question 05 Choice: </h3><p> <?php echo e($result->quest5desc); ?></p>
        <br>
        <h3>Question 06 Choice: </h3><p> <?php echo e($result->quest6desc); ?></p>
        <br>
        <h3>Question 07 Choice: </h3><p> <?php echo e($result->quest7desc); ?></p>
        <br>
        <h3>Question 08 Choice: </h3><p> <?php echo e($result->quest8desc); ?></p>
        <br>
        <h3>Question 09 Choice: </h3><p> <?php echo e($result->quest9desc); ?></p>
        <br>
        <h3>Question 10 Choice: </h3><p> <?php echo e($result->quest10desc); ?></p>
        <br>
    </div>
    <small style="font-weight:bold"> Attempted on: </small><small> <?php echo e($result->created_at); ?></small>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>