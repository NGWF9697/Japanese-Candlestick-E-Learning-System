<?php $__env->startSection('header'); ?>
    <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
        <div class="container">
            <div class="entry-header" style="text-align:center; padding-top:0;">
                <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Exercises</p>
            </div><!-- .entry-header -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li style="color:black">Exercise</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == 1): ?>
            <br>
            <button style="background-color:whitesmoke; border:none; font-weight:bold; font-size:24px;"><a href="/exercise/create"><i class="fa fa-edit"></i> Create Exercise </a></button>
            <br>
        <?php endif; ?>
    <?php endif; ?>
    <br>    
    <?php if(count($techniques) > 0): ?>
        <?php $__currentLoopData = $techniques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <p style="font-style:italic; color:grey; font-size:20px"><a href="/exercise/<?php echo e($technique->techniques); ?>" id="writing"><?php echo e($technique->techniques); ?></a></p>
                <small style="font-weight:bold">Last Updated on:</small><small> <?php echo e($technique->created_at); ?></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($techniques->links()); ?>

    <?php else: ?>
        <div class="well">
            <p>No exercises found</p>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>