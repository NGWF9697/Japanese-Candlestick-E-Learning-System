<?php $__env->startSection('content'); ?>
    <button style="background-color:whitesmoke; border:none;"><a href="/cs"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Submit Report</h1>
    <br>
        <?php echo Form::open(['action' => ['CSController@update', $cs->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <?php if(Auth::user()->acc_type != 'Admin'): ?>
                <div class="form-group">
                    <?php echo e(Form::label('type', 'Type')); ?>

                    <?php echo e(Form::select('type', array('Bug and Errors'=>'Bug and Errors', 'ID/Sign Up'=>'ID/Sign Up', 'Suggestions'=>'Suggestions', 'Report Users'=>'Report Users'), $cs->type, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('title', 'Title')); ?>

                    <?php echo e(Form::text('title', $cs->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('desc', 'Description')); ?>

                    <?php echo e(Form::textarea('desc', $cs->desc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

                </div>
            <?php else: ?>
                <h3>Type: </h3>
                <p><?php echo e($cs->type); ?></p>
                <br>
                <h3>Title: </h3>
                <p><?php echo e($cs->title); ?></p>
                <br>
                <h3>Description: </h3>
                <p><?php echo $cs->desc; ?></p>
                <br>
            <?php endif; ?>
            <?php if(Auth::user()->acc_type == 'Admin'): ?>
                <div class="form-group">
                    <?php echo e(Form::label('dev_notes', 'Description')); ?>

                    <?php echo e(Form::text('type', $cs->type, ['class' => 'form-control, hidden'])); ?>

                    <?php echo e(Form::text('title', $cs->title, ['class' => 'form-control, hidden'])); ?>

                    <?php echo e(Form::text('desc', $cs->desc, ['class' => 'form-control, hidden'])); ?>

                    <?php echo e(Form::textarea('dev_notes', $cs->dev_notes, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

                </div>
            <?php endif; ?>
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>