<?php $__env->startSection('content'); ?>
    <div class="page-header">

        <div class="page-header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <header class="entry-header">
                            <h1>Classes Online</h1>
                        </header><!-- .entry-header -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li><a href="/viewclass/<?php echo e($data = 'default'); ?>">Classes</a></li>
                        <li>MyClasses</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25">
                            <?php if(count($keyword)> 0): ?>
                                <?php $__currentLoopData = $keyword; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="/singlecourses/<?php echo e($class_name =$post->class_name); ?>"><?php echo e($post->class_name); ?></a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><?php echo e($post->created_by); ?></div>

                                            <div class="course-date"><?php echo e($post->created_at->toDateString()); ?></div>
                                            <div class="course-date"> Student <?php echo e($post->num_of_student); ?></div>  
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->
                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $ <?php echo e($post->class_price); ?> 
                                        </div><!-- .course-cost -->

                                        <div class="course-ratings flex justify-content-end align-items-center">
                                            <?php if($post->class_rating > 0 ): ?>
                                                <?php for($i = $post->class_rating; $i > 0 ; $i--): ?>
                                                    <span class="fa fa-star checked"></span>
                                                <?php endfor; ?>
                                                <?php for($i = 0; $i < 5-$post->class_rating ; $i++): ?>
                                                    <span class="fa fa-star-o"></span>
                                                <?php endfor; ?>
                                                <span class="course-ratings"><?php echo e($post->class_rating); ?></span>
                                            <?php else: ?>
                                                <p> There is no rating </p>
                                            <?php endif; ?>
                                        </div><!-- .course-ratings -->
                                    </footer><!-- .entry-footer -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php else: ?>
                                <p> No classes</p>
                            <?php endif; ?>
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .featured-courses -->
                <div class="pagination flex flex-wrap justify-content-between align-items-center">
                    <?php echo e($keyword->links()); ?>

                </div><!-- .pagination -->
            </div><!-- .col -->

            <div class="col-12 col-lg-4">
                <div class="sidebar">
                    <div class="search-widget">
                        <form class="flex flex-wrap align-items-center">
                            <input type="search" placeholder="Search...">
                            <button type="submit" class="flex justify-content-center align-items-center"><i class="fa fa-search"></i></button>
                        </form><!-- .flex -->
                    </div><!-- .search-widget -->
                    <div class="cat-links">
                            <h2>Class Management</h2>
                            <ul class="p-0 m-0">
                                <li><a href="/myclass">My Class</a></li>
                                <li><a href="/classes/create">Create Class</a></li>
                                <li><a href="#">Delete Class</a></li>
                                <li><a href="#">Joined Class</a></li>
                            </ul>
                    </div><!-- .cat-links -->

                    <div class="cat-links">
                        <h2>Categories</h2>

                        <ul class="p-0 m-0">
                            <li><a href="/search/reversal">Reversal Pattern</a></li>
                            <li><a href="/search/continuous">Continuouos Pattern</a></li>
                        </ul>
                    </div><!-- .cat-links -->

                    
                    <div class="latest-courses">
                        <h2>Latest Courses</h2>

                        <ul class="p-0 m-0">
                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-1.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">The Complete Financial Analyst Training</a></h3>

                                    <div class="course-cost free-cost">Free</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-2.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">Complete Java
                                        Masterclass</a></h3>

                                    <div class="course-cost free-cost">Free</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-3.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">The Complete Digital Marketing Course</a></h3>

                                    <div class="course-cost">$24</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-4.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">Photoshop CC 2018
                                        MasterClass</a></h3>

                                    <div class="course-cost">$18</div>
                                </div><!-- .content-wrap -->
                            </li>
                        </ul>
                    </div><!-- .latest-courses -->

                    <div class="ads">
                        <img src="images/ads.jpg" alt="">
                    </div><!-- .ads -->

                    <div class="popular-tags">
                        <h2>Popular Tags</h2>

                        <ul class="flex flex-wrap align-items-center p-0 m-0">
                            <li><a href="#">Creative</a></li>
                            <li><a href="#">Unique</a></li>
                            <li><a href="#">Photography</a></li>
                            <li><a href="#">ideas</a></li>
                            <li><a href="#">Wordpress Template</a></li>
                            <li><a href="#">startup</a></li>
                        </ul>
                    </div><!-- .popular-tags -->
                </div><!-- .sidebar -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>