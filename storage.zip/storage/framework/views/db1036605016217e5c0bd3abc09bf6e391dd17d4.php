<!DOCTYPE html>
<html lang="en">
<head>
    <title>JCS Learning</title>
    
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/elegant-fonts.css')); ?>">
    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/swiper.min.css')); ?>">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">


    <style>
        #black{
            background-color:black;
            color:white;
        }
        #black:hover{
            color:green;
        }
        .active {
            background-color: #4CAF50;
        }
        #right{
            margin-left:5%;
            margin-top:10%;
        }
        #border1{
            border: 2px solid #e1eff4;
            background-color: #f4fcff;
            border-radius: 10px;
            padding: 10px;
        }
        #writing{
            color:grey;
        }
        #writing:hover{
            color:black;
        }
        #bigdiv{
            width:100%;
            height:100%;
            background-image:url('https://paulmampillyguru.com/wp-content/uploads/2017/05/background1-1080x675.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;                       
        }
        #customWord1{
            font-family: "Brush Script MT", serif;
            text-align: center;
            font-size: 40pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord2{
            font-family: "Times New Roman", serif;
            text-align: center;
            font-size: 25pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord3{
            color:black;
            text-align: center;
            padding-top: 5px;
        }
        .form-contain{                        
            border-radius:25px;
            -webkit-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            -moz-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            background-color:whitesmoke;
            padding: 20%;
            margin-top:20%;
            opacity: 0.85;                    
        }
        .form-contain::-webkit-scrollbar{
            display:none
        }
        .hidden{
            display:none;
        }

        #backgrounds{
            background-image:url(https://willowbendanimal.com/clients/18743/images/about_us_banner.jpg);
        }
        .button1{
            display: inline-block;
            padding: 15px 25px;
            font-size: 15px;
            font-weight:900;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 15px;
            box-shadow: 0 7px #999;
        }

        .button:hover {
            background-color: #3e8e41
        }

        .button:active {
            background-color: #3e8e41;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }
    </style>
    <script>                                                      
        function openNav() {
            const mq = window.matchMedia( "(min-width: 800px)" );
           
            if (mq.matches){
                // window width is at least 800px
                document.getElementById("mySidenav").style.width = "25%";
                document.getElementById("main-menu").style.width = "25%";
            } else{
                // window width is less than 800px
                document.getElementById("mySidenav").style.width = "80%";
            }
        }
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>

</head>
<body>    
    <?php echo $__env->yieldContent('header'); ?>
    <div class="container">
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
        <?php echo $__env->yieldContent('content'); ?>        
    </div>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/d3js/5.7.0/d3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.collapsible.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/masonry.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/add.js')); ?>"></script>
</body>