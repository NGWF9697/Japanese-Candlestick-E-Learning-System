<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <header class="entry-header">
                            <h1>Detail</h1>
                        </header><!-- .entry-header -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li>Classes</li>
                        <li>Create</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->
        <div class="row">
            <div class="col-12 col-lg-8">
                <?php echo Form::open(['action' => 'ClassController@store','method' => 'POST']); ?>

                
                    <?php echo e(Form::label('text','What Will Student Learn?')); ?>

                    <textarea class="form-control" name="class_learn" cols="50" rows="10"></textarea>
                    <?php echo e(Form::label('text','Description')); ?>

                    <?php echo e(Form::textarea('class_desc','',['class' => 'form-control'])); ?>

                    <br>
                    Lecture 1
                    <input type="text" name="youtubelink" class='form-control'>
                    <br>
                    <?php echo e(Form::label('text','Description')); ?>   
                    <textarea class="form-control" name="youtubedesc" cols="50" rows="10"></textarea>
                    <br>
                    <a id="add" class = "btn" >Add more</a>
                    <br>
                    <div id="container">
                    </div>
                    <br>
                    <input type="hidden" name="class_id" value=<?php echo e(Session()->get('class_id')); ?>>
                    <?php echo e(Form::submit('Submit',['class'=>'btn btn-success'])); ?>

                
                <?php echo Form::close(); ?>

                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25" style="line-height:1px">
                        </div><!-- .col -->
                    </div><!-- .row --> 
                </div><!-- .featured-courses -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>