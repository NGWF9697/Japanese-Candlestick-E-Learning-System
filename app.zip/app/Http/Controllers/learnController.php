<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Learn;
use App\Exercise;
use Auth;
use DB;

class learnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    public function index()
    {
        $learns = Learn::orderBy('created_at', 'asc')->paginate(5);
        return view('learns.index')->with('learns', $learns);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = Auth::user();
        if($users->acc_type == 'Admin'){
            return view('learns.create');
        }
        else{            
            return redirect('/learn')->with('error', 'User do not have access');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title' => 'required',
            'picurl' => 'required'
        ]);

        //Create Post
        $learn = new Learn;
        $learn->title = $request->input('title');
        $learn->picurl = $request->input('picurl');
        $learn->desc = $request->input('desc');
        $learn->example = $request->input('example');
        $learn->user_name = auth()->user()->user_name;
        $learn->save();

        return redirect('/learn')->with('success', 'Data Inserted');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $learn = Learn::find($id);
        return view('learns.show')->with('learn', $learn);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $users = Auth::user();
        if($users->acc_type == 'Admin'){
            $learn = Learn::find($id);
            return view('learns.edit')->with('learn', $learn);
        }
        else{            
            return redirect('/learn')->with('error', 'User do not have access');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title' => 'required',
            'picurl' => 'required'
        ]);

        //Create Post
        $learn = Learn::find($id);
        $learn->title = $request->input('title');
        $learn->picurl = $request->input('picurl');
        $learn->desc = $request->input('desc');
        $learn->example = $request->input('example');
        $learn->save();

        return redirect('/learn')->with('success', 'Data Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $learn = Learn::find($id);  
        $learn->delete();

        return redirect('/learn')->with('success', 'Delete Success');
    }
}
