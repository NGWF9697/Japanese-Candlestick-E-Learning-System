<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator as Paginator;
use Illuminate\Support\Facades\Input;
use App\User;
use App\joinclass;
use App\Classes;
use App\lecture;
use Session;
use DB;

class ClassController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index','search']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $class = Classes::orderBy('created_at','desc')->paginate(5);
        return view('class.index')->with('class', $class);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user_id = auth()->user('id');
        $user = User::find($user_id->id);
        $token = $user->token;
        if($token<50){
            return redirect('/Class')->with('error','Not Enough Token to Create Class, Minumum: 50');
        }else{
            $token = $token - 50;
            $user->token = $token;
            $user->save();
            return view('class.create');
        }
    }

    public function lecture($id){
        $class = lecture::where('class_ID', $id)->paginate(1);
        return view('class.lecture')->with('class',$class);
    }
    
    public function myclass(){
        $user_id = auth()->user('id');
        $user = User::find($user_id->id);
        $class = Classes::where('created_by',$user->user_name)->paginate(5);
        return view('class.myclass')->with('class', $class);
    }

    public function search(){
        $query = Input::get('query');
        if($query!=' '){
            $class = Classes::where('created_by','LIKE','%'.$query.'%')
                        ->orWhere('class_name','LIKE','%'.$query.'%')
                        ->orWhere('class_category','LIKE','%'.$query.'%')
                        ->paginate(5);
            if(count($class) > 0 )
                return view('class.search')->with('class',$class);
        }
        return view('class.search')->with('class','Error');
    }

    public function joinclass(){
        $user_id = auth()->user('id');
        $user = User::find($user_id->id);
        if(DB::table('joinclass')->where('user_id',$user->id)->count() == 0){
            return view('class.joinclass')->with('class','Error');
        }else{
            $joinclass = DB::table('joinclass')->where('user_id',$user->id);
            $classid = $joinclass->pluck('class_ID')->all();
            $class = DB::table('Classes')->wherein('class_ID',$classid)->paginate(5);
            return view('class.joinclass')->with('class',$class);
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user = User::find($request->user_ID);
        $classdetail = Classes::where('class_ID',$request->class_ID)->first();
        $token = $user->token;
        if($token > $classdetail->class_price){
            $token = $token - $classdetail->class_price;
            $user->token = $token;
            $user->save();
            $classdetail = Classes::where('class_ID',$request->class_ID)->first();
            $owner = User::Where('user_name',$classdetail->created_by)->first();
            $owner->token = $owner->token+($classdetail->class_price/2);
            $owner->save();
            $joinclass = new joinclass;
            $joinclass->class_id = $request->class_ID;
            $joinclass->user_id = $request->user_ID;
            $joinclass->rating = 0;
            $joinclass->save();
            $class = Classes::orderBy('created_at','desc')->paginate(5);
            Session::flash('success','You have join the class');
            return view("Class.index")->with("class", $class);
        }else{
            Session::flash('error','Not Enough Token to Join. Min: 10');
            $class = Classes::orderBy('created_at','desc')->paginate(5);
            return view("Class.index")->with("class", $class);
        }   
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $class_rating = DB::table('joinclass')
                        ->where('class_ID',$id)
                        ->select(DB::raw('AVG(rating) as avg_rating'))
                        ->get();
        $rounded = round($class_rating->pluck('avg_rating')[0]);
        $content = DB::table('classes')
                        ->select('class_ID','class_name','class_price','created_by',
                                 'class_learn','class_desc','cover_image')
                        ->where('class_ID',$id)
                        ->get();
        $links = DB::table('lecture')
                        ->where('class_ID',$id)
                        ->get();
        
        $result = $content->push($links);
        
        $result = $content->push(['class_avg_rating' =>$rounded]);
        $checkExist = DB::table('joinclass')
                        ->where([['class_ID','=',$id],['user_id','=',auth()->user('id')->id]])
                        ->exists();                        
        $result = $result->push(['Exists' => $checkExist]);
        return view('class.show')->with('class', $result);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $query = Input::get('rating');
        $user_id = auth()->user('id');
        $user = User::find($user_id->id);
        $joinclass = joinclass::where([['class_ID','=',$id],
                                        ['user_id','=',$user->id]    
                                    ,])->update(array('rating'=>$query));
                                    
        $joinclass = DB::table('joinclass')->where('user_id',$user->id); 
        $classid = $joinclass->pluck('class_ID')->all();
        $class = Classes::wherein('class_ID',$classid)->paginate(5);
        return view('class.joinclass')->with('class',$class);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Classes::where('class_ID','=',$id)->delete();
        $user_id = auth()->user('id');
        $user = User::find($user_id->id)->first();
        $token = $user->token;
        $token = $token + 25;
        $user->token = $token;
        $user->save();
        $class = Classes::where('created_by',$user->user_name)->paginate(5);
        return view('class.myclass')->with('class', $class);
    }
}
