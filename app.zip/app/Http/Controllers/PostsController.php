<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Classes;
use App\User;
use App\lecture;
use DB;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //regular expression for youtube link from the url
        $regex = 'http( |s):\/\/www\.youtube\.com\/watch\?v\=\w*';

        //input is the request from the form
        $input = $request->all();

        //validation rule
        $rule = array(
            'class_name' => 'required|unique:Classes,class_name',
            'class_category' => 'required',
            'class_learn' => 'required',
            'class_desc' => 'required',
            'cover_image' => 'image|nullable|mimes:jpg,jpeg|max:1999',
            'youtubelink' => array('required','regex:~'.$regex.'~'),
            'youtubedesc' => 'required',
            'youtubelink1' => array('sometimes','required_without:NULL','regex:~'.$regex.'~'),
            'youtubedesc1' => 'sometimes|required_without:NULL',
            'youtubelink2' => array('sometimes','required_without:NULL','regex:~'.$regex.'~'),
            'youtubedesc2' => 'sometimes|required_without:NULL',
            'youtubelink3' => array('sometimes','required_without:NULL','regex:~'.$regex.'~'),
            'youtubedesc3' => 'sometimes|required_without:NULL',
            'youtubelink4' => array('sometimes','required_without:NULL','regex:~'.$regex.'~'),
            'youtubedesc4' => 'sometimes|required_without:NULL',);

        //message is the message display if condition met
        $message = array('class_name.unique'=>'Name already Exists',
                        'class_learn.required'=>'Learning Outcome is required',
                        'class_desc.required' => 'Description for class is required',
                        'cover_image.mimes' => 'Image must be in .jpg format',
                        'cover_image.max' => 'Image file too big',
                        'youtubelink.required' => 'Link for Lecture 1 is required',
                        'youtubedesc.required' => 'Description for Lecture 1 is required',
                        'youtubelink1.required_without' => 'Link for Lecture 2 is required',
                        'youtubedesc1.required_without' => 'Description for Lecture 2 is required',
                        'youtubelink2.required_without' => 'Link for Lecture 3 is required',
                        'youtubedesc2.required_without' => 'Description for Lecture 3 is required',
                        'youtubelink3.required_without' => 'Link for Lecture 4 is required',
                        'youtubedesc3.required_without' => 'Description for Lecture 4 is required',
                        'youtubelink4.required_without' => 'Link for Lecture 5 is required',
                        'youtubedesc4.required_without' => 'Description for Lecture 5 is required',
                        'youtubelink.regex' => 'Link for Lecture 1 is not correct, Please copy directly from the URL',
                        'youtubelink1.regex' => 'Link for Lecture 2 is not correct, Please copy directly from the URL',
                        'youtubelink2.regex' => 'Link for Lecture 3 is not correct, Please copy directly from the URL',
                        'youtubelink3.regex' => 'Link for Lecture 4 is not correct, Please copy directly from the URL',
                        'youtubelink4.regex' => 'Link for Lecture 5 is not correct, Please copy directly from the URL',
                        );

        //make the validator
        $validator = Validator::make($input,$rule,$message);

        //if validate fail return back to current page
        if ($validator->fails()){
            return redirect('/Class/create')
                        ->withErrors($validator);

        //if correct continue
        }else{
            if($request->hasFile('cover_image')){
                //Get filename with the extension
                $fileNameWithExt = $request->file('cover_image')->getClientOriginalName();
                //Get just filename
                $filename = pathinfo($fileNameWithExt,PATHINFO_FILENAME);
                //Get just ext
                $extension = $request->file('cover_image')->getClientOriginalExtension();
                //Filename to store
                $fileNameToStore = $filename.'_'.time().'.'.$extension;
                //Upload Image
                $path = $request->file('cover_image')->storeAs('public/cover_image',$fileNameToStore);
            }else {
                $fileNameToStore = 'noimage.jpg' ;
            }
            //get user stuff
            $user_id = auth()->user('id');
            $user = User::find($user_id);
            $post = new Classes;
            $post->class_name = $request->input('class_name');
            $post->class_price = 50;
            $post->class_category = $request->input('class_category');
            $post->created_by = $user->pluck("user_name")[0];
            $post->class_learn = $request->class_learn;
            $post->class_desc = $request->class_desc;
            $post->cover_image = $fileNameToStore;
            $post->save();

            //get the class ID
            $class = Classes::where('class_name','=',$request->input('class_name'))->first();
            //First Lecture
            $lecture = new lecture;
            $lecture->class_ID = $class->class_ID;
            $lecture->Lecture = 1;
            $lecture->youtube_link = $request->youtubelink;
            $lecture->youtube_desc = $request->youtubedesc;
            $lecture->save();
            
            //insert to if have additional lecture
            if($request->has('youtubelink1') and $request->has('youtubedesc1')){
                $lecture = new lecture;
                $lecture->class_ID = $class->class_ID;
                $lecture->Lecture = 2;
                $lecture->youtube_link = $request->youtubelink1;
                $lecture->youtube_desc = $request->youtubedesc1;
                $lecture->save();
            }
            if($request->has('youtubelink2') and $request->has('youtubedesc2')){
                $lecture = new lecture;
                $lecture->class_ID = $class->class_ID;
                $lecture->Lecture = 3;
                $lecture->youtube_link = $request->youtubelink1;
                $lecture->youtube_desc = $request->youtubedesc1;
                $lecture->save();
            }
            if($request->has('youtubelink3') and $request->has('youtubedesc4')){
                $lecture = new lecture;
                $lecture->class_ID = $class->class_ID;
                $lecture->Lecture = 4;
                $lecture->youtube_link = $request->youtubelink1;
                $lecture->youtube_desc = $request->youtubedesc1;
                $lecture->save();
            }
            if($request->has('youtubelink4') and $request->has('youtubedesc4')){
                $lecture = new lecture;
                $lecture->class_ID = $class->class_ID;
                $lecture->Lecture = 5;
                $lecture->youtube_link = $request->youtubelink1;
                $lecture->youtube_desc = $request->youtubedesc1;
                $lecture->save();
            }
        }
        return redirect('/Class/myclass');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($data)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

}
