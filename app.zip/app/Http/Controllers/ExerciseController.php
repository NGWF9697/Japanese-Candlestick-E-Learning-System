<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exercise;
use App\techniques;
use Auth;
use DB;

class ExerciseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    
    public function index()
    {
        $techniques = techniques::where('status', '=', 'Complete')->paginate(5);
        return view('exercise.index')->with('techniques', $techniques);
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = Auth::user();
        if($users->acc_type == 'Admin'){
            return view('exercise.create');
        }
        else{            
            return redirect('/exercise')->with('error', 'User do not have access');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'techniques' => 'required',
            'questionnum' => 'required',
            'questiondesc' => 'required',
            'ansA' => 'required',
            'ansB' => 'required',
            'correctans' => 'required'
        ]);

        $insertion = (string)$request->input('techniques').(string)$request->input('questionnum');
        $check1 = Exercise::where('questionnum', '=', $insertion)->first();
        $techniques = techniques::where('techniques', '=', $request->input('techniques'))->get()->first();        

        if($check1 == null){
            $exercise = new Exercise;
            $exercise->techniques = $request->input('techniques');
            $exercise->questionnum = $insertion;
            $exercise->questiondesc = $request->input('questiondesc');
            $exercise->question = $request->input('questionnum');
            $exercise->qurl = $request->input('qurl');
            $exercise->ansA = $request->input('ansA');
            $exercise->ansB = $request->input('ansB');
            $exercise->ansC = $request->input('ansC');
            $exercise->ansD = $request->input('ansD');
            $exercise->ansE = $request->input('ansE');
            $exercise->correctans = $request->input('correctans');
            $exercise->save();

            $check2 = Exercise::where('techniques', '=', $request->input('techniques'))->get()->count();

            if($check2 >= 10){
                $techniques->status = "Complete";
            }
            else{
                $techniques->status = "Incomplete";
            }
            $techniques->save();
            return redirect('/exercise/create')->with('success', 'Data Inserted');
        }
        else{
            return redirect('/exercise/create')->with('error', 'Data Existed');
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$exercise = chapter::where('chapter', '=', 'Chapter 1')->first()->exercise;
        //$exercise = DB::select('SELECT*FROM exercises WHERE chapter = Chapter 1');
        $text = (string)$id;
        $techniques = Exercise::where('techniques', '=', $text)->orderby('question', 'asc')->get();
        return view('exercise.show', ['techniques' => $techniques]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $users = Auth::user();
        if($users->acc_type == 'Admin'){
            $exercise = Exercise::find($id);
            return view('exercise.edit')->with('exercise', $exercise);
        }
        else{            
            return redirect('/exercise')->with('error', 'User do not have access');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'questiondesc' => 'required',
            'ansA' => 'required',
            'ansB' => 'required',
            'correctans' => 'required'
        ]);

        $insertion = (string)$request->input('techniques').(string)$request->input('questionnum');
        $exercise = Exercise::find($id);
        $exercise->questiondesc = $request->input('questiondesc');
        $exercise->qurl = $request->input('qurl');
        $exercise->ansA = $request->input('ansA');
        $exercise->ansB = $request->input('ansB');
        $exercise->ansC = $request->input('ansC');
        $exercise->ansD = $request->input('ansD');
        $exercise->ansE = $request->input('ansE');
        $exercise->correctans = $request->input('correctans');
        $exercise->save();

        return redirect('/exercise/create')->with('success', 'Data Inserted');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $exercise = Exercise::find($id);
        $exercise->delete();

        return redirect('/exercise')->with('success', 'Delete Success');
    }
}
