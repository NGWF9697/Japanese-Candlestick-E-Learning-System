<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use App\Exercise;
use App\techniques;
use App\Results;
use App\update;
use App\Progress;

class QuizController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()
    {
        //$results = Results::find(Auth::user()->user_name);
        $user_name = Auth::user()->user_name;
        $results = Results::where('user_name', '=', $user_name)->orderby('created_at', 'desc')->get();
        return view('quiz.index')->with('results', $results);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $number = 0;
        $results = new Results;
        $users = Auth::user();
        $progress = Progress::find($users->id);
        $results->title = $request->input('name');
        $results->user_name = $users->user_name;
        
        if($request->input('Question01Question01') == $request->input('Question01')){
            $number += 1;
            $results->quest1 = 'Correct';
            $results->quest1desc = $request->input('Question01');
        }
        else{
            $results->quest1 = 'Wrong';
            $results->quest1desc = $request->input('Question01');
        }
        if($request->input('Question02Question02') == $request->input('Question02')){
            $number += 1;
            $results->quest2 = 'Correct';
            $results->quest2desc = $request->input('Question02');
        }
        else{
            $results->quest2 = 'Wrong';
            $results->quest2desc = $request->input('Question02');
        }
        if($request->input('Question03Question03') == $request->input('Question03')){
            $number += 1;
            $results->quest3 = 'Correct';
            $results->quest3desc = $request->input('Question03');
        }
        else{
            $results->quest3 = 'Wrong';
            $results->quest3desc = $request->input('Question03');
        }
        if($request->input('Question04Question04') == $request->input('Question04')){
            $number += 1;
            $results->quest4 = 'Correct';
            $results->quest4desc = $request->input('Question04');
        }
        else{
            $results->quest4 = 'Wrong';
            $results->quest4desc = $request->input('Question04');
        }
        if($request->input('Question05Question05') == $request->input('Question05')){
            $number += 1;
            $results->quest5 = 'Correct';
            $results->quest5desc = $request->input('Question05');
        }
        else{
            $results->quest5 = 'Wrong';
            $results->quest5desc = $request->input('Question05');
        }
        if($request->input('Question06Question06') == $request->input('Question06')){
            $number += 1;
            $results->quest6 = 'Correct';
            $results->quest6desc = $request->input('Question06');
        }
        else{
            $results->quest6 = 'Wrong';
            $results->quest6desc = $request->input('Question06');
        }
        if($request->input('Question07Question07') == $request->input('Question07')){
            $number += 1;
            $results->quest7 = 'Correct';
            $results->quest7desc = $request->input('Question07');
        }
        else{
            $results->quest7 = 'Wrong';
            $results->quest7desc = $request->input('Question07');
        }
        if($request->input('Question08Question08') == $request->input('Question08')){
            $number += 1;
            $results->quest8 = 'Correct';
            $results->quest8desc = $request->input('Question08');
        }
        else{
            $results->quest8 = 'Wrong';
            $results->quest8desc = $request->input('Question08');
        }
        if($request->input('Question09Question09') == $request->input('Question09')){
            $number += 1;
            $results->quest9 = 'Correct';
            $results->quest9desc = $request->input('Question09');
        }
        else{
            $results->quest9 = 'Wrong';
            $results->quest9desc = $request->input('Question09');
        }
        if($request->input('Question10Question10') == $request->input('Question10')){
            $number += 1;
            $results->quest10 = 'Correct';
            $results->quest10desc = $request->input('Question10');
        }
        else{
            $results->quest10 = 'Wrong';
            $results->quest10desc = $request->input('Question10');
        }
        $results->num_correct = $number;
        $results->save();

        $users->token = $users->token + 5;
        $level = $users->level;
        $xp = $users->xp;
        $alert = 0;
        $current = floor( ( $level* ( log10($level) ) *1000 ) );
        $users->xp = $xp + 200 + ( 200 * ( log10($level) ) );
        if($xp >= $current ){
            $users->level = $level + 1;
            $users->xp = $xp - $current;
        }
        $progress->do_progress_1 = $progress->do_progress_1 + 1;
        $progress->save();
        $users->save();
        
        if($number > 5){
            if($number == 10){
                return redirect('/exercise')->with('success', 'Congratulations You completed the quiz and have all questions correct !!!');
            }
            else{
                return redirect('/exercise')->with('success', 'Congratulations You completed the quiz and have more than 5 questions correct !!!');
            }
        }
        else{
            return redirect('/exercise')->with('success', 'Congratulations You completed the quiz');
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = Results::find($id);
        return view('quiz.show')->with('result', $result);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
