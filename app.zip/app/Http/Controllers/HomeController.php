<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\update;
use Auth;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $updates = update::orderBy('created_at', 'desc')->get();
        return view('home')->with('updates', $updates);
    }
}
