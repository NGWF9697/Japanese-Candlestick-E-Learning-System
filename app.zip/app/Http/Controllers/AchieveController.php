<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Progress;
use App\User;

class AchieveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()
    {

        $user = Auth::user();
        $user_id = $user->id;
        $progress = Progress::where('user_id', '=',$user_id)->get()->first();
        return view('achievement.index')->with('progress', $progress);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = Auth::user();
        $user_id = $user->id;
        $progress = Progress::where('user_id', '=', $user_id)->get()->first();
        $user->token = $user->token + $request->input('token');
        $progress->claimed1 = $progress->claimed1 + $request->input('claimed1');
        $progress->claimed2 = $progress->claimed2 + $request->input('claimed2');
        $progress->claimed3 = $progress->claimed3 + $request->input('claimed3');
        $progress->claimed4 = $progress->claimed4 + $request->input('claimed4');
        $progress->claimed5 = $progress->claimed5 + $request->input('claimed5');
        $progress->claimed6 = $progress->claimed6 + $request->input('claimed6');
        $progress->save();
        $user->save();

        return redirect('/achievement')->with('success', 'Token Claimed');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
