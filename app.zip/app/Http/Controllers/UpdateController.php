<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\update;
use DB;

class UpdateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $updates = update::orderBy('title', 'asc');
        return view('home')->with('updates', $updates);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('update.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $updates = new update;        
        $updates->title = $request->input('title');
        $updates->desc = $request->input('desc');
        $updates->type = $request->input('type');    
        $updates->save();

        return redirect('/')->with('success', 'Data Inserted');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $update = update::find($id);
        return view('update.show')->with('update', $update);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $update = update::find($id);
        return view('update.edit')->with('update', $update);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $update = update::find($id);
        $update->title = $request->input('title');
        $update->desc = $request->input('desc');
        $update->type = $request->input('type');    
        $update->save();

        return redirect('/')->with('success', 'Data Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $update = Update::find($id);
        $update->delete();

        return redirect('/')->with('success', 'Delete Success');
    }
}
