<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Facedes\Input;
use App\Classes;
use DB;
use App\User;


class PagesController extends Controller
{
    public function about(){
        return view('pages.about');      
    }
}
