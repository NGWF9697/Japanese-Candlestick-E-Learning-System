<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Content extends Model
{
    //Table Name
    protected $table = 'class_content';
    //Primary key
    public $PrimaryKey = 'class_ID';
     //timestamp
    public $timestamps = false;

}
