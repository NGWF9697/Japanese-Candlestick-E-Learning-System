<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Results extends Model
{
    protected $table = 'Results';
    public $primaryKey = 'id';
    public $timestamps = true;
}
