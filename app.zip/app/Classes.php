<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classes extends Model
{
    //Table Name
    protected $table = 'classes';
    //Primary key
    public $PrimaryKey = 'class_ID';

    //timestamp
    public $timestamps = true;

}
