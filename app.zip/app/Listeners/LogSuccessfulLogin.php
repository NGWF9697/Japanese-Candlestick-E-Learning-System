<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Login;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Auth;
use App\User;
use \DateTime;

class LogSuccessfulLogin
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  Login  $event
     * @return void
     */
    public function handle(Login $event)
    {
        $user = Auth::user();
        $user_login = $user->login;
        $datetime1 = new DateTime($user->login);
        $datetime2 = new DateTime(date('Y-m-d H:i:s'));
        $interval = $datetime1->diff($datetime2);
        $days = $interval->format('%a');
        if ($days >= 1){
            $user->token = $user->token + 1;
            $user->save();
        }
        $event->user->login = date('Y-m-d H:i:s');
        $event->user->save();
    }
}
