<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    protected $table = 'exercises';
    public $primaryKey = 'id';
    public $timestamps = true;
}
