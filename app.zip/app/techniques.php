<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class techniques extends Model
{
    protected $table = 'techniques';
    public $primaryKey = 'id';
    public $timestamps = true;
}
