<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lecture extends Model
{
    ///Table Name
    protected $table = 'lecture';
    //Primary key
    public $PrimaryKey = 'class_ID';
     //timestamp
    public $timestamps = false;
}
