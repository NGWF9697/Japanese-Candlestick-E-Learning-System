<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class joinclass extends Model
{
    ///Table Name
    protected $table = 'joinclass';
    //Primary key
    public $PrimaryKey = 'class_ID';
     //timestamp
    public $timestamps = false;

}
