<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class update extends Model
{
    protected $table = 'updates';
    public $primaryKey = 'id';
    public $timestamps = true;
}
