<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CS extends Model
{
    protected $table = 'c_s';
    public $primaryKey = 'id';
    public $timestamps = true;
}
