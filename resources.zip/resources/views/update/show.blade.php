@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br><br>
    <h1 style="text-shadow: 5px 5px 5px grey; text-align:center">{{$update->title}}</h1>    
    <br>
    <div>
        <img src="{{$update->picurl}}" style="display: block; margin-left: auto; margin-right: auto;">
    </div>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Description</h1>
        <p>{!!$update->desc!!}</p>
    </div>
    <hr>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey; font-style:italic">Update Type</h3>
        <p>{!!$update->type!!}</p>
    </div>
    <br>
    <small style="font-weight:bold">Last Updated on: </small><small> {{$update->created_at}}</small>
    @if(!Auth::guest())
        @if(Auth::user()->acc_type == "Admin")
            <br><br>
            <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/update/{{$update->id}}/edit/"><i class="fa fa-edit"></i> Edit</a></button>
            {!!Form::open(['action' => ['UpdateController@destroy', $update->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
    <br><br>
@endsection