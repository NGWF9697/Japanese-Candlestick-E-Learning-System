<!DOCTYPE html>
<html lang="en">
<head>
    <title>JCS Learning</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="{{asset('css/font-awesome.min.css')}}">
    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="{{asset('css/elegant-fonts.css')}}">
    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="{{asset('css/themify-icons.css')}}">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="{{asset('css/swiper.min.css')}}">
    <!-- Styles -->
    <link rel="stylesheet" href="{{asset('style.css')}}">

    {{-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> --}}

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <style>
        .active {
            background-color: #4CAF50;
        }
        #right{
            margin-left:5%;
            margin-top:10%;
        }
        #border1{
            border: 2px solid #e1eff4;
            background-color: #f4fcff;
            border-radius: 10px;
            padding: 10px;
        }
        #writing{
            color:grey;
        }
        #writing:hover{
            color:black;
        }
        #bigdiv{
            width:100%;
            height:100%;
            background-image:url('https://paulmampillyguru.com/wp-content/uploads/2017/05/background1-1080x675.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;                       
        }
        #customWord1{
            font-family: "Brush Script MT", serif;
            text-align: center;
            font-size: 40pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord2{
            font-family: "Times New Roman", serif;
            text-align: center;
            font-size: 30pt;
            font-weight:bold;
            color: black;
            font-style:italic;
        }
        #customWord3{
            color:black;
            text-align: center;
            padding-top: 5px;
        }
        .form-contain{                        
            border-radius:25px;
            -webkit-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            -moz-box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            box-shadow: 0px 0px 120px 0px rgba(0,0,0,1);
            background-color:whitesmoke;
            padding: 20%;
            margin-top:20%;
            opacity: 0.85;                    
        }
        .form-contain::-webkit-scrollbar{
            display:none
        }
        #hide{
            display:block;
        }        
        .hidden{
            display:none;
        }

        #backgrounds{
            background-image:url(https://willowbendanimal.com/clients/18743/images/about_us_banner.jpg);
        }
        #edit1{
            background-color:  #80b3ff;
            padding: 10px;
        }
        section{
            float:left;
            margin: 0 1.5%;
            width: 10%;
            border:2px solid white;
        }
        #collapse1{
            background-color:white;
        }
        .tabs{
            background-color:black;
            border: 2px solid black;                    
            padding: 15px;
        }
        #tab1{
            background-color:black;
            color:white;
            border-style: transparent;
            font-weight: bold;
            border: none;
            outline: none;
        }
        #tab1:hover{
            color:grey;
            border-style: transparent;
        }
        #tab1:active{
            color:grey;
        }
        .buttonedit{
            background-color: black;
            text-decoration: underline;
            text-decoration-color: white;
            padding: 15px 32px;
            text-align: center;
            color:white;
            font-weight:bold;
            border:none;
        }
        .buttonedit:hover{
            background-color:grey;
        }
        .buttoneditcolor{
            background-color: green;
        }
        .con1{
            border: 2px solid black;
            text-align: left;
            padding: 10px;
            width: 100%;
            height:400px;
            overflow-y:scroll;
        }
        hr{
            background-color:grey;
        }
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 50%;
            margin-left:auto;
            margin-right:auto;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        @media screen and (max-width: 500px) {
            #hide{
                float:none;
                display:none;
            }
        }
        .mySlides {display:none}
        .w3-left, .w3-right, .w3-badge {cursor:pointer}
        .w3-badge {height:13px;width:13px;padding:0}
    </style>
    <script>                                                      
        function openNav() {
            const mq = window.matchMedia( "(min-width: 800px)" );
           
            if (mq.matches){
                // window width is at least 800px
                document.getElementById("mySidenav").style.width = "25%";
                document.getElementById("main-menu").style.width = "25%";
            } else{
                // window width is less than 800px
                document.getElementById("mySidenav").style.width = "80%";
            }
        }
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>

</head>
<body>
    @include('inc.topnav')
    @yield('header')
    <div style="background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSreSi6JorKmLRhx85ic3ca4glBG7qac8b1v2WKaUtid8jL57XAqA); width:100%; height:100%; background-repeat:no-repeat; background-size: cover;">
        <br>
        <div class="container" style="box-shadow: 5px 5px 18px; border: 2px solid; background-color:whitesmoke;">
            <br>
            @include('inc.messages')
            @yield('content')        
        </div>
        <br>
    </div>
    @include('inc.footer')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
    <script>
        CKEDITOR.replace('ckeditor1');
        CKEDITOR.replace('ckeditor2');
        CKEDITOR.replace('ckeditor3');

        $('textarea.ckeditor').each(function () {
            var $textarea = $(this);
            $textarea.val(CKEDITOR.instances[$textarea.attr('name')]);
            console.log($textarea.attr('name'));
        });
    </script>
    <script type='text/javascript' src="{{asset('js/add.js')}}"></script>
    <script type='text/javascript' src="{{asset('js/app.js')}}"></script>
    <script type='text/javascript' src="{{asset('public/js/jquery.js')}}"></script>
    <script type='text/javascript' src="{{asset('js/swiper.min.js')}}"></script>
    <script type='text/javascript' src="{{asset('js/masonry.pkgd.min.js')}}"></script>
    <script type='text/javascript' src="{{asset('js/jquery.collapsible.min.js')}}"></script>
    <script type='text/javascript' src="{{asset('js/custom.js')}}"></script>
</body>