@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/profile" style="background-color:whitesmoke; color:black"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br>
    <h3 style="text-shadow: 5px 5px 5px grey; text-align:center"> Benefits of being a tutor</h3>
    <br>
    <ul class="p-0 m-0 green-ticked">
        <li>Able to earn more tokens.</li>
        <li>Able to spread own knowledge and understandings.</li>
        <li>Able to tutor other people.</li>
    </ul>
    <br>
    <h3 style="text-shadow: 5px 5px 5px grey; text-align:center">Rules & Regulations</h3>
    <br>
    <ul>
        <li><p>Do not simply create classes.</p></li>
        <li><p>Do not include knowledge which is unrelated to Japanese Candlestick.</p></li>
        <li><p>Do not share wrong knowledge.</p></li>
    </ul>
    {!! Form::open(['action' => ['tutorController@update', $user->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        {{Form::text('pass', 'Active', ['class' => 'form-control, hidden'])}}
        {{Form::number('token', $user->token - 100, ['class' => 'form-control, hidden'])}}
        {{Form::hidden('_method', 'PUT')}}
        <br>
        {{Form::submit('Apply Now', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
    <br>
    
@endsection