@extends('layout.app')
@section('header')
    <div class="page-header">
        <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
            <div class="container">
                <div class="entry-header" style="text-align:center; padding-top:0;">
                    <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">About Us</p>
                </div>
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->
@endsection
@section('content')
    <div class="container">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li style="color:black">About</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        <div class="row">
            <div class="col-12">
                <div class="about-heading">
                    <h2 class="entry-title" style="font-weight: bold; text-shadow: 2px 2px black">Welcome to JCS-Learning</h2>
                    <br>
                    <p style="text-decoration: underline">A platform for people to learn and master Japanese Candlestick techniques in stock market</p>                    
                    <p>This website is create for users who wish to improve their Japanese Candlestick skills. Users can also share their knowledge by aquiring the tutor status. By gaining the tutor access, users can create their own classes and share their knowledge to other users.</p>
                </div><!-- .about-heading -->
                <hr>
            </div><!-- .col -->
            <div class="col-12 col-lg-6">
                <div class="about-stories">
                    <h3>Student's Guides</h3>

                    <p>Guides for new users</p>

                    <p>In this application you will get to learn and master the following items: </p>

                    <ul class="p-0 m-0 green-ticked">
                        <li>Learn how to differentiate different types of candles</li>
                        <li>Learn Japanese Candlestick techniques</li>
                        <li>Learn how to predict the outcome</li>
                    </ul><!-- .green-ticked -->
                </div><!-- .about-stories -->
            </div><!-- .col -->

            <div class="col-12 col-lg-6">
                <div class="about-values">
                    <h3>Tutor's Guide</h3>

                    <p>Guides for new tutors</p>

                    <p>Basic requirements for new tutors that wish to teach other users and create classes: </p>

                    <ul class="p-0 m-0 green-ticked">
                        <li>Have at least 100 coins</li>
                        <li>Account must be at least 1 months old</li>
                        <li>Completed all the basic exercises</li>
                    </ul><!-- .green-ticked -->
                    <br>
                </div><!-- .about-values -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
@endsection