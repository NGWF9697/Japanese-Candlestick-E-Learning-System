@extends('layout.app1')
@section('header')
    <div id="bigdiv">
        <div class="container-fluid">
            <br>
            <button class="button1"><a href="/"><i class="fa fa-arrow-left"></i> Home </button></a>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-8 col-sm-12 col-xs-12">
                        <p style="color:white; font-size:70px;text-align:center;font-style:italic;text-shadow:2px 2px green">JCS Learning </p><br>
                    <div class="form-contain">
                        <p id="customWord1">Reset Password </p><br>
                        <div class="card-body">
                            {!! Form::open(['action' => ['resetController@update', 1] , 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
                                @csrf
                                <div class="form-group row">
                                    <label for="user_name" id="customWord2">{{ __('User Name:') }}</label>
                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="user_name" type="text" class="form-control" name="user_name" value="{{ old('user_name') }}" required autofocus>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="hint" id="customWord2">{{ __('Hint:') }}</label>
                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="hint" type="text" class="form-control" name="hint" required autofocus>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="password"id="customWord2">{{ __('New Password:') }}</label>
                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                                        @if ($errors->has('password'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="password-confirm" id="customWord2">{{ __('Confirm Password:') }}</label>
                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div style="text-align:center">
                                        <button type="submit" class="btn btn-primary" style="font-size:20px;">
                                            {{ __('Reset') }}
                                        </button><br><br>
                                    </div>
                                </div>
                                <div style="text-align:center">
                                    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px; opacity: 0.85;"><a href="/login" style="font-style:italic;"><i class="fa fa-male" style="font-size:30px"></i>  Old User ? <i class="fa fa-female" style="font-size:30px"></i></a></button>
                                </div>
                                {{Form::hidden('_method', 'PUT')}}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
@endsection