@extends('layout.app')
@section('header')
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Create Class</p>
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
@endsection
@section('content')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li>Classes</li>
                        <li>Create</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
            {!! Form::open(['action' => 'PostsController@store','method' => 'POST','enctype'=>'multipart/form-data']) !!}
                {{form::label('text','Class Name :')}}
                <input type="text" class="awesome{{ $errors->has('class_name') ? ' is-invalid' : '' }}" name="class_name" value="{{ old('class_name') }}" required autofocus>
                @if ($errors->has('class_name'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('class_name') }}</strong>
                    </span>
                @endif
                    {{form::label('Pattern','Category :')}}
                    
                    {{form::select('class_category',[
                    'Single Reversal Pattern' => 'Single Reversal Pattern',

                    'Double Reversal Pattern' => 'Double Reversal Pattern',

                    'Triple Reversal Pattern' => 'Triple Reversal Pattern',

                    'Multiple Reversal Pattern' => 'Multiple Reversal Pattern',

                    'Double Continuous Pattern' => 'Double Continuous Pattern',

                    'Multiple Continuous Pattern' => 'Multiple Continuous Pattern' ,

                    'Window' =>'Window'
                    ],'',['class' => 'form-group'])}}
                    {{-- <form action='/content/store' method="POST">  --}}
                    <br>
                    {{Form::label('text','Icon For Your Class')}}
                    {{Form::file('cover_image')}}
                    <br>
                    {{Form::label('text','What Will Student Learn?')}}
                    <textarea class="ckeditor" name="class_learn" cols="50" rows="10"></textarea>
                    {{Form::label('text','Description')}}
                    {{Form::textarea('class_desc','',['class' => 'ckeditor'])}}
                    <br>
                    Lecture 1
                    <input type="text" name="youtubelink" class='form-control' placeholder="Please Enter Youtube Link Here">
                    <br>
                    {{Form::label('text','Description')}}   
                    <textarea class="ckeditor" name="youtubedesc" cols="50" rows="10"></textarea>
                    <div id='lecture1' style="display:none;">
                        <br>
                        Lecture 2
                        <input type="text" name="youtubelink1" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        {{Form::label('text','Description')}}   
                        <textarea class="ckeditor" name="youtubedesc1" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture2' style="display:none">
                        <br>
                        Lecture 3
                        <input type="text" name="youtubelink2" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        {{Form::label('text','Description')}}   
                        <textarea class="ckeditor" name="youtubedesc2" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture3' style="display:none">
                        <br>
                        Lecture 4
                        <input type="text" name="youtubelink3" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        {{Form::label('text','Description')}}   
                        <textarea class="ckeditor" name="youtubedesc3" cols="50" rows="10" disabled></textarea>
                    </div>
                    <div id='lecture4' style="display:none">
                        <br>
                        Lecture 5
                        <input type="text" name="youtubelink4" class='form-control' placeholder="Please Enter Youtube Link Here" disabled>
                        <br>
                        {{Form::label('text','Description')}}   
                        <textarea class="ckeditor" name="youtubedesc4" cols="50" rows="10" disabled></textarea>
                    </div>
                    <br>
                    <a id="add" class = "btn">Add more</a>
                    <a id="remove" class = "btn">Remove</a>
                    <br>
                    <br>
                    <input type="submit" class="btn btn-success">
                    <input type="reset" class="btn btn-success">
                {!! Form::close() !!}
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->

@endsection