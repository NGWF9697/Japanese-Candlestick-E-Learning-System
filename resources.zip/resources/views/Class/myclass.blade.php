@extends('layout.app')
@section('header')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">My Classes</p>
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
@endsection
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li><a href="/Class">Classes</a></li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25">
                            @if($class!='Error')
                                @foreach($class as $post)
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="{{action("ClassController@show",['id'=>$post->class_ID])}}">{{$post->class_name}}</a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="{{action("ClassController@search",[$post->created_by])}}">{{$post->created_by}} </a></div>

                                            <div class="course-date">{{$post->created_at->toDateString()}}</div>
 
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->
                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $ {{$post->class_price}} 
                                        </div><!-- .course-cost -->
                                        {!!Form::open(['action'=>['ClassController@destroy',$post->class_ID], 'method' =>'POST','class' =>'pull-right'])!!}
                                            {{Form::hidden('_method','DELETE')}}
                                            {{Form::submit('Delete',['class' => 'btn btn-danger'])}}
                                        {!!Form::close()!!}
                                        <div class="course-ratings flex justify-content-end align-items-center">
                                            
                                        </div><!-- .course-ratings -->
                                    </footer><!-- .entry-footer -->
                                @endforeach 
                            @else
                                <p>No Match Keyword</p>
                            @endif
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .featured-courses -->
                <div class="pagination flex flex-wrap justify-content-between align-items-center">
                @if($class!='Error')
                    {{$class->links()}}
                @endif
                </div><!-- .pagination -->
            </div><!-- .col -->

            <div class="col-12 col-lg-4">
                <div class="sidebar" style="border:none">
                    <div class="search-widget" style="border-style:solid;border-width:2px;border-color:gray">
                        {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                            {{ csrf_field() }}
                            <input type="search" placeholder="Search..." name="query">
                            <button type="submit" value="search" class="flex justify-content-center align-items-center"><i class="fa fa-search"></i></button>
                        {!! Form::close() !!}
                    </div><!-- .search-widget -->
                    <div class="cat-links">
                            <h2>Class Management</h2>
                            {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                            <ul class="p-0 m-0">
                                @if(!(auth()->user('id')== null))
                                    <li><a href="{{action('ClassController@myclass')}}">My Class</a></li>
                                    <li><a href="{{action('ClassController@create')}}">Create Class</a></li>
                                    <li><a href="/Class/joinclass">Joined Class</a></li>
                                @else
                                    <li><a href="/login">Login to view</a></li>
                                @endif
                            </ul>
                            {!! Form::close() !!}
                    </div><!-- .cat-links -->

                    <div class="cat-links">
                        <h2>Categories</h2>

                        {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                        <ul class="p-0 m-0">
                                {{csrf_field()}}
                                <li><input type="submit" name="query" value="Single Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Triple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" value="Window" style="border:none;background:none"></li>
                        </ul>
                        {!! Form::close() !!}
                    </div><!-- .cat-links -->
    
                        
                        {{-- <div class="latest-courses">
                            <h2>Latest Courses</h2>
    
                            <ul class="p-0 m-0">
                                <li class="flex flex-wrap justify-content-between align-items-center">
                                    <img src="images/t-1.jpg" alt="">
    
                                    <div class="content-wrap">
                                        <h3><a href="#">The Complete Financial Analyst Training</a></h3>
    
                                        <div class="course-cost free-cost">Free</div>
                                    </div><!-- .content-wrap -->
                                </li>
    
                                <li class="flex flex-wrap justify-content-between align-items-center">
                                    <img src="images/t-2.jpg" alt="">
    
                                    <div class="content-wrap">
                                        <h3><a href="#">Complete Java
                                            Masterclass</a></h3>
    
                                        <div class="course-cost free-cost">Free</div>
                                    </div><!-- .content-wrap -->
                                </li>
    
                                <li class="flex flex-wrap justify-content-between align-items-center">
                                    <img src="images/t-3.jpg" alt="">
    
                                    <div class="content-wrap">
                                        <h3><a href="#">The Complete Digital Marketing Course</a></h3>
    
                                        <div class="course-cost">$24</div>
                                    </div><!-- .content-wrap -->
                                </li>
    
                                <li class="flex flex-wrap justify-content-between align-items-center">
                                    <img src="images/t-4.jpg" alt="">
    
                                    <div class="content-wrap">
                                        <h3><a href="#">Photoshop CC 2018
                                            MasterClass</a></h3>
    
                                        <div class="course-cost">$18</div>
                                    </div><!-- .content-wrap -->
                                </li>
                            </ul>
                        </div><!-- .latest-courses --> --}}
    
                        {{-- <div class="ads">
                            <img src="images/ads.jpg" alt="">
                        </div><!-- .ads -->
    
                        <div class="popular-tags">
                            <h2>Popular Tags</h2>
    
                            <ul class="flex flex-wrap align-items-center p-0 m-0">
                                <li><a href="#">Creative</a></li>
                                <li><a href="#">Unique</a></li>
                                <li><a href="#">Photography</a></li>
                                <li><a href="#">ideas</a></li>
                                <li><a href="#">Wordpress Template</a></li>
                                <li><a href="#">startup</a></li>
                            </ul>
                        </div><!-- .popular-tags --> --}}
                    </div><!-- .sidebar -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
@endsection