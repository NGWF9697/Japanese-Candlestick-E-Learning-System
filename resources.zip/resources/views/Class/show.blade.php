@extends('layout.app')
@section('header')
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">{{$class[0]->class_name}}</p>
            <div class="ratings flex justify-content-center align-items-center">
                <input type="hidden" value="{{$rating = array_get($class[2],'class_avg_rating')}}">
                @if( $rating > 0 )
                    @for($i = $rating ; $i > 0 ; $i--)
                        <span class="fa fa-star checked"></span>
                    @endfor
                    @for($i = 0; $i < 5-$rating  ; $i++)
                        <span class="fa fa-star-o"></span>
                    @endfor
                    <span class="course-ratings" style="font-style:italic; font-size: 25px; font-weight:bold;color:black">{{$rating}}</span>
                @else
                    <p> There is no rating </p>
                @endif
            </div><!-- .ratings -->
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
@endsection
@section('content')
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="breadcrumbs">
                <ul class="flex flex-wrap align-items-center p-0 m-0">
                    <li><a href="/"><i class="fa fa-home"></i>Home</a></li>
                    <li><a href="/Class">Classes</a></li>
                    <li>{{$class->pluck('class_name')[0]}}</li>
                </ul>
            </div><!-- .breadcrumbs -->
        </div><!-- .col -->
    </div><!-- .row -->
    <div class="container">
        <div class="row">
            <div class="col-12 offset-lg-1 col-lg-10">
                <div class="featured-image">
                    {{-- {{dd($class[0]->cover_image)}} --}}
                    <img src="/storage/cover_image/{{$class[0]->cover_image}}" alt="noimage.jpg">
                    <div class="course-cost">
                        <div class="free-cost"><i class="fa fa dollar"> $</i>{{$class->pluck('class_price')[0]}}</div>
                    </div>
                </div>
            </div><!-- .col -->
        </div><!-- .row -->
    </div>
    <div class="row">
        <div class="col-12 offset-lg-1 col-lg-1">
            <div class="post-share">
                <h3>share</h3>

                <ul class="flex flex-wrap align-items-center p-0 m-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-thumb-tack"></i></a></li>
                </ul>
            </div><!-- .post-share -->
        </div><!-- .col -->

        <div class="col-12 col-lg-8">
            <div class="single-course-wrap">
                <div class="course-info flex flex-wrap align-items-center">
                    <div class="course-author flex flex-wrap align-items-center mt-3">
                        {{-- <img src="images/course-author.jpg" alt=""> --}}
                        
                        <div class="author-wrap">
                            <label class="m-0">Teacher</label>
                            <div class="author-name"><a href="#">{{$class->pluck('created_by')[0]}}</a></div>
                        </div><!-- .author-wrap -->
                    </div><!-- .course-author -->

                    <div class="course-cats mt-3">
                        <label class="m-0">{{$class->pluck('class_category')[0]}}</label>
                        <div class="author-name"><a href="#">Web design</a></div>
                    </div><!-- .course-cats -->

                    <div class="course-students mt-3">
                        <label class="m-0">Student</label>
                            <input type="hidden" value="
                            {{$count = DB::table('joinclass')->where('class_id',$class->pluck('class_ID')[0])->count()}}">
                            <div class="author-name"><a href="#">
                            @if($count>0)
                            {{$count}}
                            (REGISTERED)
                            @else
                            0 (REGISTERED)
                            @endif
                            </a>
                            </div>
                    </div><!-- .course-students -->

                    <div class="buy-course mt-3">
                        @if(!array_get($class[3],'Exists'))
                        {!! Form::open(['action' => 'ClassController@store','method' => 'POST']) !!}
                            <input type="hidden" name="class_ID" value="{{$class->pluck('class_ID')[0]}}">
                            <input type="hidden" name="user_ID" value="{{auth()->user('id')->id}}">
                            <button type="submit" style="background:none;border:none"><a class="btn">Join Class</a></button>
                        {!! Form::close() !!}
                        @else
                        <button type="submit" style="border:none;background:none"><a class="btn" href="/Class/lecture/{{$class->pluck('class_ID')[0]}}">Start</a></button>
                        @endif
                    </div><!-- .buy-course -->
                </div><!-- .course-info -->

                <div class="single-course-cont-section">
                    <h2>What Will I Learn?</h2>
                    <ul class="p-0 m-0 green-ticked">
                        @if(strpos($class->pluck('class_learn')[0],"\n")!== false)
                            @foreach (explode("\n",$class->pluck('class_learn')[0]) as $words)
                                <li>{{strip_tags($words)}}</li>
                            @endforeach
                        @else
                            <li>{{strip_tags($class->pluck('class_learn')[0])}}</li>
                        @endif
                    </ul>
                    <h2>Description</h2>
                    @if(strpos($class->pluck('class_desc')[0],"\n")!== false)
                        @foreach (explode("\r",$class->pluck('class_desc')[0]) as $words)
                            <li>{{strip_tags($words)}}</li>
                        @endforeach
                    @else
                        <li>{{strip_tags($class->pluck('class_desc')[0])}}</li>
                    @endif

                </div>

                <div class="single-course-accordion-cont mt-3">
                    <header class="entry-header flex flex-wrap justify-content-between align-items-center">
                        <h2>Curriculum For This Course</h2>
                        <div class="number-of-lectures">{{sizeof($class[1])}} Lectures</div>
                        <div class="total-lectures-time"></div>
                    </header><!-- .entry-header -->

                    <div class="entry-contents">
                        <div class="accordion-wrap type-accordion">
                            <h3 class="entry-title flex flex-wrap justify-content-between align-items-lg-center">
                                {{-- <span class="arrow-r"><i class="fa fa-plus"></i><i class="fa fa-minus"></i></span> --}}
                                <span class="lecture-group-title">{{$class->pluck('class_name')[0]}}</span>
                                <span class="number-of-lectures">{{sizeof($class[1])}} Lectures</span>
                                <span class="total-lectures-time"></span>
                            </h3>
                            <div class="ent ry-content">
                                    <ul class="p-0 m-0">
                                        @foreach($class[1] as $count)
                                            <li class="flex flex-column flex-lg-row align-items-lg-center"><span class="lecture-title">
                                            {{Youtube::getVideoInfo(Youtube::parseVidFromURL($count->youtube_link))->snippet->title}}</span>
                                            <span class="lectures-preview"></span>
                                            <input type ="hidden" value="{{$duration =Youtube::getVideoInfo(Youtube::parseVidFromURL($count->youtube_link))->contentDetails->duration}}">
                                            <input type ="hidden" value="{{preg_match_all('!\d+!', $duration, $format)}}">
                                            </span><span class="lectures-time text-left text-lg-right">
                                            <input type ="hidden" value="{{$minute = $format[0][0]}}">
                                            <input type ="hidden" value="{{$second = $format[0][1]}}">
                                            @if(strlen((string)$format[0][0])==1)
                                                <input type ="hidden" value="{{$minute ="0".$minute}}">
                                            @endif
                                            @if(strlen((string)$format[0][1])==1)
                                                <input type ="hidden" value="{{$second ="0".$second}}">
                                            @endif
                                            {{$minute}}:{{$second}}
                                            </span></li>
                                        @endforeach
                                    </ul>
                            </div>
                        </div>
                    </div>
                    </div>
                        
                {{-- <div class="instructors-info">
                    <header class="entry-heading">
                        <h2 class="entry-title">Instructors</h2>
                    </header><!-- .entry-heading -->

                    <div class="instructor-short-info flex flex-wrap">
                        <div class="instructors-stats">
                            <img src="images/instructor.jpg" alt="">

                            <ul class="p-0 m-0 mt-3">
                                <li><i class="fa fa-star"></i> 4.7 .7 Average rating</li>
                                <li><i class="fa fa-comment"></i> 25,182 Reviews</li>
                                <li><i class="fa fa-user"></i> 11,085 Students</li>
                                <li><i class="fa fa-play-circle"></i> 2 Courses</li>
                            </ul>
                        </div><!-- .instructors-stats -->

                        <div class="instructors-details">
                            <div class="ratings flex align-items-center">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                                <span> (4 votes)</span>
                            </div><!-- .ratings -->

                            <h2 class="entry-title mt-3">The Unreal Engine Developer Course Learn C++ & Make Games</h2>

                            <div class="course-teacher mt-3">
                                Teacher: <a href="#">Ms. Lara Croft</a>
                            </div><!-- .course-teacher -->

                            <div class="entry-content mt-3">
                                <p>Hi! I'm Colt. I'm a developer with a serious love for teaching. I've spent the last few years teaching people to program at 2 different immersive bootcamps where I've helped hundreds of people become web developers and change their lives. My graduates work at companies like Google, Salesforce, and Square.</p>
                            </div><!-- .entry-content -->
                        </div><!-- .instructors-details -->
                    </div><!-- .instructor-short-info -->
                </div><!-- .instructors-info -->

                <div class="related-courses">
                    <header class="entry-heading flex flex-wrap justify-content-between align-items-center">
                        <h2 class="entry-title">Related Courses</h2>

                        <a href="#">View all</a>
                    </header><!-- .entry-heading -->

                    <div class="row mx-m-25">
                        <div class="col-12 col-lg-6 px-25">
                            <div class="course-content">
                                <figure class="course-thumbnail">
                                    <a href="#"><img src="images/3.jpg" alt=""></a>
                                </figure><!-- .course-thumbnail -->

                                <div class="course-content-wrap">
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="#">The Complete Digital Marketing Course</a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="#">Ms. Lucius</a></div>

                                            <div class="course-date">Dec 18, 2018</div>
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->

                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $55 <span class="price-drop">$78</span>
                                        </div><!-- .course-cost -->

                                        <div class="course-ratings flex justify-content-end align-items-center">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star-o"></span>

                                            <span class="course-ratings-count">(4 votes)</span>
                                        </div><!-- .course-ratings -->
                                    </footer><!-- .entry-footer -->
                                </div><!-- .course-content-wrap -->
                            </div><!-- .course-content -->
                        </div><!-- .col -->

                        <div class="col-12 col-lg-6 px-25">
                            <div class="course-content">
                                <figure class="course-thumbnail">
                                    <a href="#"><img src="images/2.jpg" alt=""></a>
                                </figure><!-- .course-thumbnail -->

                                <div class="course-content-wrap">
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="#">The Ultimate Drawing Course Beginner to Advanced</a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="#">Michelle Golden</a></div>

                                            <div class="course-date">Mar 14, 2018</div>
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->

                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            <span class="free-cost">Free</span>
                                        </div><!-- .price-drop -->

                                        <div class="course-ratings flex justify-content-end align-items-center">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star-o"></span>

                                            <span class="course-ratings-count">(4 votes)</span>
                                        </div><!-- .course-ratings -->
                                    </footer><!-- .entry-footer -->
                                </div><!-- .course-content-wrap -->
                            </div><!-- .course-content -->
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .related-course --> --}}
            </div><!-- .single-course-wrap -->
        </div><!-- .col -->
    </div><!-- .row -->
</div><!-- .container -->

<div class="clients-logo" style="background:none">
    {{-- <div class="container">
        <div class="row">
            <div class="col-12 flex flex-wrap justify-content-center justify-content-lg-between align-items-center">
                <div class="logo-wrap">
                    <img src="images/logo-1.png" alt="">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="images/logo-2.png" alt="">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="images/logo-3.png" alt="">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="images/logo-4.png" alt="">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="images/logo-5.png" alt="">
                </div><!-- .logo-wrap -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container --> --}}
</div><!-- .clients-logo -->
@endsection