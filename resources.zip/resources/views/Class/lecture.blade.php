@extends('layout.app')
@section('header')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
    <div class="container">
        <div class="entry-header" style="text-align:center; padding-top:0;">
            <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Lecture {{$class[0]->Lecture}}</p>
        </div><!-- .entry-header -->
    </div><!-- .container -->
</div><!-- .page-header-overlay -->
@endsection
@section('content')
@if(count($class)>0)
    @foreach($class as $count)
        <div class="page-header">
            <div class="page-header-overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <header class="entry-header">
                                <h1 class="entry-title">Lecture {{$count->Lecture}}</h1>   
                                <div class="ratings flex justify-content-center align-items-center">
                                </div><!-- .ratings -->
                            </header><!-- .entry-header -->
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .page-header-overlay -->
        </div><!-- .page-header -->
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumbs">
                        <ul class="flex flex-wrap align-items-center p-0 m-0">
                            <li><a href="/"><i class="fa fa-home"></i>Home</a></li>
                            <li><a href="/Class">Classes</a></li>
                            <li><span class="lecture-title"><a href="{{action("ClassController@show",['id'=>$count->class_ID])}}">
                            {{DB::table('classes')->where('class_ID',$count->class_ID)->select('class_name')->get()->pluck('class_name')[0]}}</span></a></li>
                            <li>Lecture {{array_get($count[1],'lecture')}}</li>
                        </ul>
                    </div><!-- .breadcrumbs -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
        <center>
        <br>
        <h1 style="text-shadow: 5px 5px 5px grey; text-align:center">{{Youtube::getVideoInfo(Youtube::parseVidFromURL($count->youtube_link))->snippet->title}}</h1>    
        <br>
        <br>
        <div>
            <iframe width="420" height="315" src="https://www.youtube.com/embed/{{explode('v=',$count->youtube_link)[1]}}">></iframe>
        </div>
        </center>
        <br>
        <div class="container">
            <h1 style="text-shadow: 5px 5px 5px grey">Description</h1>
            <p>{!!$count->youtube_desc!!}</p>
        </div>
        <br>
    @endforeach
    {{$class->links()}}
    <script>
        $("#pagination").on("load",function(){
            x = document.getElementsByClassName('pagination');
            x.style.text-align = "center";
        }
    </script>
@endif

<br><br>
@endsection