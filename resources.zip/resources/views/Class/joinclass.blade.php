@extends('layout.app')
@section('content')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="page-header">

        <div class="page-header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <header class="entry-header">
                            <h1>Classes Online</h1>
                        </header><!-- .entry-header -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-header-overlay -->
    </div><!-- .page-header -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs">
                    <ul class="flex flex-wrap align-items-center p-0 m-0">
                        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                        <li><a href="/Class">Classes</a></li>
                        <li>Joined</li>
                    </ul>
                </div><!-- .breadcrumbs -->
            </div><!-- .col -->
        </div><!-- .row -->

        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="featured-courses courses-wrap">
                    <div class="row mx-m-25">
                        <div class="col-12 col-md-6 px-25">
                            @if($class == 'error')
                                <p>You haven join any class</p>
                            @else
                                @foreach($class as $post)
                                    <header class="entry-header">
                                        <h2 class="entry-title"><a href="{{action("ClassController@show",['id'=>$post->class_ID])}}">{{$post->class_name}}</a></h2>

                                        <div class="entry-meta flex flex-wrap align-items-center">
                                            <div class="course-author"><a href="/viewclass/{{$created_by = $post->created_by}}">{{$post->created_by}} </a></div>
                                            <div class="course-date">{{explode(' ',$post->created_at)[0]}}</div>
 
                                        </div><!-- .course-date -->
                                    </header><!-- .entry-header -->
                                    <footer class="entry-footer flex flex-wrap justify-content-between align-items-center">
                                        <div class="course-cost">
                                            $ {{$post->class_price}}
                                        </div><!-- .course-cost -->
                                        <input type="hidden" value="{{$rated = DB::table("joinclass")->where([
                                            ['class_ID',$post->class_ID],
                                            ['user_id',auth()->user('id')->id]
                                            ])->get()}}">

                                        @if($rated[0]->rating == 0.0)
                                            <div class="course-ratings flex justify-content-end align-items-center">
                                                {!!Form::open(['action' => ['ClassController@update',$post->class_ID],'method'=>'POST'])!!}
                                                    <button type="submit" name="rating" style="background:none;border:none" value="1"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="2"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="3"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="4"><span class="fa fa-star checked"></span></button>
                                                    <button type="submit" name="rating" style="background:none;border:none" value="5"><span class="fa fa-star checked"></span></button>
                                                    <div class="course-thumbnail" style="text-align:center">Click to Rate</div><!-- .course-cost -->
                                                {!!Form::hidden('_method','PUT')!!}
                                                {!!Form::close()!!}
                                            </div><!-- .course-ratings -->
                                        @else
                                            <div class="course-ratings flex justify-content-end align-items-center">
                                                <input type="hidden" value="{{$rating = DB::table('joinclass')
                                                                ->where('class_ID',$post->class_ID)
                                                                ->select(DB::raw('AVG(rating) as avg_rating'))
                                                                ->get()}}">
                                                @for($i = round($rating[0]->avg_rating) ; $i > 0 ; $i--)
                                                    <span class="fa fa-star checked"></span>
                                                @endfor
                                                @for($i = 0; $i < 5-round($rating[0]->avg_rating)  ; $i++)
                                                    <span class="fa fa-star-o"></span>
                                                @endfor
                                                <span class="course-ratings">{{round($rating[0]->avg_rating)}}</span>
                                            </div><!-- .course-ratings -->
                                        @endif
                                    </footer><!-- .entry-footer -->
                                @endforeach 
                            @endif
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .featured-courses -->
                <div class="pagination flex flex-wrap justify-content-between align-items-center">
                    {{$class->links()}}
                </div><!-- .pagination -->
            </div><!-- .col -->

            <div class="col-12 col-lg-4">
                <div class="sidebar">
                    <div class="search-widget" style="border-style:solid;border-width:2px;border-color:gray">
                        {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                            {{ csrf_field() }}
                            <input type="search" placeholder="Search..." name="query">
                            <button type="submit" value="search" class="flex justify-content-center align-items-center"><i class="fa fa-search"></i></button>
                        {!! Form::close() !!}
                    </div><!-- .search-widget -->
                    <div class="cat-links">
                            <h2>Class Management</h2>
                            {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                            <ul class="p-0 m-0">
                                @if(!(auth()->user('id')== null))
                                    <li><a href="{{action('ClassController@myclass')}}">My Class</a></li>
                                    <li><a href="{{action('ClassController@create')}}">Create Class</a></li>
                                    <li><a href="/Class/joinclass" style="background:none !important">Joined Class</a></li>
                                @else
                                    <li><a href="/login">Login to view</a></li>
                                @endif
                            </ul>
                            {!! Form::close() !!}
                    </div><!-- .cat-links -->

                    <div class="cat-links">
                        <h2>Categories</h2>

                        {!! Form::open(['action' => 'ClassController@search','method' => 'post','class' => 'flex flex-wrap align-items-center','role'=>'serach']) !!}
                        <ul class="p-0 m-0">
                                {{csrf_field()}}
                                <li><input type="submit" name="query" value="Single Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Triple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Reversal Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Double Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" name="query" value="Multiple Continuous Pattern" style="border:none;background:none"></li>
                                <li><input type="submit" value="Window" style="border:none;background:none"></li>
                        </ul>
                        {!! Form::close() !!}
                    </div><!-- .cat-links -->

                    
                    {{-- <div class="latest-courses">
                        <h2>Latest Courses</h2>

                        <ul class="p-0 m-0">
                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-1.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">The Complete Financial Analyst Training</a></h3>

                                    <div class="course-cost free-cost">Free</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-2.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">Complete Java
                                        Masterclass</a></h3>

                                    <div class="course-cost free-cost">Free</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-3.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">The Complete Digital Marketing Course</a></h3>

                                    <div class="course-cost">$24</div>
                                </div><!-- .content-wrap -->
                            </li>

                            <li class="flex flex-wrap justify-content-between align-items-center">
                                <img src="images/t-4.jpg" alt="">

                                <div class="content-wrap">
                                    <h3><a href="#">Photoshop CC 2018
                                        MasterClass</a></h3>

                                    <div class="course-cost">$18</div>
                                </div><!-- .content-wrap -->
                            </li>
                        </ul>
                    </div><!-- .latest-courses -->

                    <div class="ads">
                        <img src="images/ads.jpg" alt="">
                    </div><!-- .ads -->

                    <div class="popular-tags">
                        <h2>Popular Tags</h2>

                        <ul class="flex flex-wrap align-items-center p-0 m-0">
                            <li><a href="#">Creative</a></li>
                            <li><a href="#">Unique</a></li>
                            <li><a href="#">Photography</a></li>
                            <li><a href="#">ideas</a></li>
                            <li><a href="#">Wordpress Template</a></li>
                            <li><a href="#">startup</a></li>
                        </ul>
                    </div><!-- .popular-tags --> --}}
                </div><!-- .sidebar -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
@endsection