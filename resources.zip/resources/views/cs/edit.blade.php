@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none;"><a href="/cs"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Submit Report</h1>
    <br>
        {!! Form::open(['action' => ['CSController@update', $cs->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
            @if(Auth::user()->acc_type != 'Admin')
                <div class="form-group">
                    {{Form::label('type', 'Type')}}
                    {{Form::select('type', array('Bug and Errors'=>'Bug and Errors', 'ID/Sign Up'=>'ID/Sign Up', 'Suggestions'=>'Suggestions', 'Report Users'=>'Report Users'), $cs->type, ['class' => 'form-control'])}}
                </div>
                <div class="form-group">
                    {{Form::label('title', 'Title')}}
                    {{Form::text('title', $cs->title, ['class' => 'form-control', 'placeholder' => 'Title'])}}
                </div>
                <div class="form-group">
                    {{Form::label('desc', 'Description')}}
                    {{Form::textarea('desc', $cs->desc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])}}
                </div>
            @else
                <h3>Type: </h3>
                <p>{{$cs->type}}</p>
                <br>
                <h3>Title: </h3>
                <p>{{$cs->title}}</p>
                <br>
                <h3>Description: </h3>
                <p>{!!$cs->desc!!}</p>
                <br>
            @endif
            @if(Auth::user()->acc_type == 'Admin')
                <div class="form-group">
                    {{Form::label('dev_notes', 'Description')}}
                    {{Form::text('type', $cs->type, ['class' => 'form-control, hidden'])}}
                    {{Form::text('title', $cs->title, ['class' => 'form-control, hidden'])}}
                    {{Form::text('desc', $cs->desc, ['class' => 'form-control, hidden'])}}
                    {{Form::textarea('dev_notes', $cs->dev_notes, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])}}
                </div>
            @endif
            {{Form::hidden('_method', 'PUT')}}
            {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        {!! Form::close() !!}
    <br>
@endsection