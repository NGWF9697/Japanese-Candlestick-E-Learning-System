@extends('layout.app')
@section('header')
    <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
        <div class="container">
            <div class="entry-header" style="text-align:center; padding-top:0;">
                <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Customer Services</p>
            </div><!-- .entry-header -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
@endsection
@section('content')
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li style="color:black">Customer Service</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <br>
    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/cs/create"><i class="fa fa-edit"></i> Send In A Report</a></button>
    <br><br>
    @if(count($cs) > 0)
        @foreach($cs as $css)
            <div class="well">
                <p style="font-style:italic; color:grey; font-size:20px"><a href="/cs/{{$css->id}}" id="writing">{{$css->title}}</a></p>
                <small style="font-weight:bold">Last Updated on:</small><small> {{$css->updated_at}}</small>
            </div>
        @endforeach
        {{$cs->links()}}
    @else
        <div class="well">
            <p>No Report found</p>
        </div>
    @endif

@endsection