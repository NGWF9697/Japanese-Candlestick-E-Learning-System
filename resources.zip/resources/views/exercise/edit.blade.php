@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none;"><a href="/exercise"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Edit Exercise</h1>
    <br>
        {!! Form::open(['action' => ['ExerciseController@update', $exercise->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
            <div class="form-group">
                <h3> Techniques :</h3>
                <p>{!!$exercise->techniques!!}</p>
            </div>
            <div class="form-group">
                <h3> Question :</h3>
                <p>{!!$exercise->question!!}</p>
                <br>
            </div>
            <div class="form-group">                
                {{Form::label('questiondesc', 'Question Description')}}
                {{Form::textarea('questiondesc', $exercise->questiondesc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Description'])}}
            </div>
            <div class="form-group">
                    {{Form::label('qurl', 'Question URL')}}
                    {{Form::text('qurl', $exercise->qurl, ['class' => 'form-control', 'placeholder' => 'URL'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansA', 'Answer Description For A')}}
                    {{Form::text('ansA', $exercise->ansA, ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansB', 'Answer Description For B')}}
                    {{Form::text('ansB', $exercise->ansB, ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansC', 'Answer Description For C')}}
                    {{Form::text('ansC', $exercise->ansC, ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansD', 'Answer Description For D')}}
                    {{Form::text('ansD', $exercise->ansD, ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansE', 'Answer Description For E')}}
                    {{Form::text('ansE', $exercise->ansE, ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('correctans', 'Correct Answer')}}
                    {{Form::text('correctans', $exercise->correctans, ['class' => 'form-control', 'placeholder' => 'Correct Answer'])}}
            </div>
            {{Form::hidden('_method', 'PUT')}}
            {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        {!! Form::close() !!}
        <br>
        {!!Form::open(['action' => ['ExerciseController@destroy', $exercise->id], 'method' => 'POST'])!!}
            {{Form::hidden('_method', 'DELETE')}}
            {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
        {!!Form::close()!!}
    <br>
@endsection