@extends('layout.app')
@section('header')
    <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
        <div class="container">
            <div class="entry-header" style="text-align:center; padding-top:0;">
                <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Exercises</p>
            </div><!-- .entry-header -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
@endsection
@section('content')
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li style="color:black">Exercise</li>
        </ul>
    </div><!-- .breadcrumbs -->
    @if(!Auth::guest())
        @if(Auth::user()->acc_type == 'Admin')
            <br>
            <button style="background-color:whitesmoke; border:none; font-weight:bold; font-size:24px;"><a href="/exercise/create"><i class="fa fa-edit"></i> Create Exercise </a></button> <button style="background-color:whitesmoke; border:none; font-weight:bold; font-size:24px; float:right"><a href="/quiz"><i class="glyphicon glyphicon-file"></i> Check Past Results </a></button>
            <br>
        @else
            <button style="background-color:whitesmoke; border:none; font-weight:bold; font-size:24px; float:right"><a href="/quiz"><i class="glyphicon glyphicon-file"></i> Check Past Results </a></button>
            <br>
        @endif
    @endif
    <br>    
    @if(count($techniques) > 0)
        @foreach($techniques as $technique)
            <div class="well">
                <p style="font-style:italic; color:grey; font-size:20px"><a href="/exercise/{{$technique->techniques}}" id="writing">{{$technique->techniques}}</a></p>
            </div>
        @endforeach
        {{$techniques->links()}}
    @else
        <div class="well">
            <p>No exercises found</p>
        </div>
    @endif
@endsection