@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none;"><a href="/exercise"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Create Exercise</h1>
    <br>
        {!! Form::open(['action' => 'ExerciseController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
            <div class="form-group">
                {{Form::label('techniques', 'Techniques')}}
                {{Form::select('techniques',[
                    'Single Reversal Pattern' => ['hammer'=>'Hammer','hanging_man'=>'Hanging Man','inverted_hammer'=>'Inverted Hammer',
                    'shooting_star'=>'Shooting Star','doji_at_the_bottom'=>'Doji At The Bottom','doji_at_the_top'=>'Doji At The Top',
                    'bullish_meeting_line'=>'Bullish Meeting Line','bearish_meeting_line'=>'Bearish Meeting Line',
                    'bullish_belt_hold_line'=>'Bullish Belt Hold Line','bearish_belt_hold_line'=>'Bearish Belt Hold Line'],

                    'Double Reversal Pattern' => ['bullish_engulfing'=>'Bullish Engulfing','bearish_engulfing'=>'Bearish Engulfing',
                    'fred_tam’s_white_inside_out_up'=>'Fred Tam’s White Inside Out Up','fred_tam’s_black_inside_out_down'=>'Fred Tam’s Black Inside Out Down'
                    ,'piercing_line'=>'Piercing Line','dark_cloud_cover'=>'Dark Cloud Cover','bullish_harami_line'=>'Bullish Harami Line',
                    'bearish_harami_line'=>'Bearish Harami Line','bullish_harami_cross'=>'Bullish Harami Cross',
                    'bearish_harami_cross'=>'Bearish Harami Cross','homing_pigeon'=>'Homing Pigeon','bearish_homing_pigeon'=>'Bearish Homing Pigeon',
                    'tweezers_bottom'=>'Tweezers Bottom','tweezers_top'=>'Tweezers Top'],

                    'Triple Reversal Pattern' => ['star_at_the_bottom'=>'Star At The Bottom','star_at_the_top'=>'Star At The Top',
                    'river_morning_doji_star'=> 'River Morning Doji Star','river_evening_doji_star'=>'River Evening Doji Star',
                    'abandon_baby_bottom'=>'Abandon Baby Bottom','abandon_baby_top'=>'AbandonBaby Top',
                    'three-river_evening_star'=>'Three-River Evening Star','three-river_morning_star'=>'Three-River Morning Star',
                    'tri-star_bottom'=>'Tri-Star Bottom','tri-star_top'=>'Tri-Star Top',
                    'breakaway_three_new_price_bottom'=>'Breakaway Three New Price Bottom',
                    'breakaway_three_new_price_top'=>'Breakaway Three New Price Top',
                    'bullish_black_three-gaps'=>'Bullish Black Three-Gaps','bearish_white_three-gaps'=>'Bearish White Three-Gaps',
                    'three_black_crows'=>'Three Black Crows','deliberation'=>'Deliberation','upside_gap_two_crows'=>'Upside Gap Two Crows'],

                    'Multiple Reversal Pattern' =>['concealing_baby_swallow'=>'Concealing Baby Swallow','ladder_bottom'=>'Ladder Bottom',
                    'tower_bottom'=>'Tower Bottom','tower_top'=>'Tower Top',
                    'eight-to-ten_new_price_low'=>'Eight-To-Ten New Price Low','eight-to-ten_new_price_high'=>'Eight-To-Ten New Price High'],

                    'Double Continuous Pattern' =>['bullish_separating_line'=>'Bullish Separating Line',
                    'bearish_separating_line'=>'Bearish Separating Line','bullish_kicking_pattern'=>'Bullish Kicking Pattern',
                    'bearish_kicking_pattern'=>'Bearish Kicking Pattern','on-neck_line'=>'On-Neck Line',
                    'in-neck_line'=>'In-Neck Line','thrusting_line'=>'Thrusting Line'],

                    'Multiple Continuous Pattern' =>['rising_three_methods'=>'Rising Three Methods',
                    'falling_three_method'=>'Falling Three Method','mat_hold_pattern'=>'Mat Hold Pattern'],

                    'Window' =>['tasuki_upside_gap'=>'Tasuki Upside Gap','tasuki_downside_gap'=>'Tasuki Downside Gap',
                    'upgap_side-by-side_white_lines'=>'Upgap Side-By-Side White Lines',
                    'downgap_side-by-side_white_lines'=>'Downgap Side-By-Side White Lines',
                    'high-price_gapping_play'=>'High-Price Gapping Play','low-price_gapping_play'=>'Low-Price Gapping Play']
                    ], '',['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('questionnum', 'Question Number')}}
                {{Form::select('questionnum',array('Question01'=>'Question01', 'Question02'=>'Question02', 'Question03'=>'Question03', 'Question04'=>'Question04', 'Question05'=>'Question05', 'Question06'=>'Question06', 'Question07'=>'Question07', 'Question08'=>'Question08', 'Question09'=>'Question09', 'Question10'=>'Question10'), '', ['class' => 'form-control'])}}
            </div>
            <div class="form-group">
                {{Form::label('questiondesc', 'Question Description')}}
                {{Form::textarea('questiondesc', '', ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Description'])}}
            </div>
            <div class="form-group">
                    {{Form::label('qurl', 'Question URL')}}
                    {{Form::text('qurl', '', ['class' => 'form-control', 'placeholder' => 'URL'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansA', 'Answer Description For A')}}
                    {{Form::text('ansA', '', ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansB', 'Answer Description For B')}}
                    {{Form::text('ansB', '', ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansC', 'Answer Description For C')}}
                    {{Form::text('ansC', '', ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansD', 'Answer Description For D')}}
                    {{Form::text('ansD', '', ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('ansE', 'Answer Description For E')}}
                    {{Form::text('ansE', '', ['class' => 'form-control', 'placeholder' => 'Answer'])}}
            </div>
            <div class="form-group">
                    {{Form::label('correctans', 'Correct Answer')}}
                    {{Form::text('correctans', '', ['class' => 'form-control', 'placeholder' => 'Correct Answer'])}}
            </div>
            {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        {!! Form::close() !!}
    <br>
@endsection