@extends('layout.app')
@section('header')
    <div class="page-header-overlay" style="background-image:url('http://metromidsayap-water.gov.ph/wp-content/uploads/2016/11/Header-Background.jpg'); background-size:cover; background-repeat:no-repeat;">
        <div class="container">
            <div class="entry-header" style="text-align:center; padding-top:0;">
                <p style="font-style:italic; font-size: 50px; font-weight:bold; text-shadow: 2px 2px 2px black">Exercises</p>
            </div><!-- .entry-header -->
        </div><!-- .container -->
    </div><!-- .page-header-overlay -->
@endsection
@section('content')
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div class="breadcrumbs" style="font-weight:bold">
        <ul class="flex flex-wrap align-items-center p-0 m-0">
            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="/exercise"> Exercise</a></li>
            <li style="color:black; font-style:italic">Quiz</li>
        </ul>
    </div><!-- .breadcrumbs -->
    <br>
    {!! Form::open(['action' => 'QuizController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        @if(count($techniques) > 0)
            @if(count($techniques) < 10)
                <div class="well">
                    <p>Not Enough Questions, Please contact admin to add more questions</p>
                </div>
            @else
                @foreach($techniques as $technique)
                    <div class="well" style="text-align:center">
                        <h1>{{$technique->question}}</h1>
                        @if($technique->qurl != null)
                            <div>
                                <img src={{$technique->qurl}} style="width:90%">
                            </div>
                        @endif
                        <br>
                        <h4 style="text-decoration:underline; font-style:italic">{!!$technique->questiondesc!!}</h4>
                            <div class="container" style="text-align:left">
                            @if($technique->ansA != null)
                                {{Form::radio($technique->question, $technique->ansA, ['class' => 'form-control'])}} {{$technique->ansA}}
                                <br>
                            @endif
                            @if($technique->ansB != null)
                                {{Form::radio($technique->question, $technique->ansB, ['class' => 'form-control'])}} {{$technique->ansB}}
                                <br>
                            @endif
                            @if($technique->ansC != null)
                                {{Form::radio($technique->question, $technique->ansC, ['class' => 'form-control'])}} {{$technique->ansC}}
                                <br>
                            @endif
                            @if($technique->ansD != null)
                                {{Form::radio($technique->question, $technique->ansD, ['class' => 'form-control'])}} {{$technique->ansD}}
                                <br>
                            @endif
                            @if($technique->ansE != null)
                                {{Form::radio($technique->question, $technique->ansE, ['class' => 'form-control'])}} {{$technique->ansE}}
                                <br>
                            @endif
                            @if(!Auth::guest())
                                @if(Auth::user()->acc_type == 'Admin')
                                    <br><br>
                                    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/exercise/{{$technique->id}}/edit"><i class="fa fa-edit"></i> Edit</a></button>
                                @endif
                        @endif
                        </div>
                        {{Form::text($technique->question.$technique->question, $technique->correctans, ['class' => 'form-control, hidden'])}}
                        {{Form::text('name', $technique->techniques, ['class' => 'form-control, hidden'])}}
                    </div>
                @endforeach
                @if(!Auth::guest())
                    {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
                @endif
            @endif
        @else
            <div class="well">
                <p>No exercises found</p>
            </div>
        @endif
    {!! Form::close() !!}
    <br>
@endsection