@extends('layout.app')
@section('content')
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/profile" style="background-color:whitesmoke; color:black"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br><br>
    <h3 style="text-shadow: 5px 5px 5px grey; text-align:center">{{$users->user_name}}</h3>
    <br>
    <div style="text-align:center">
        <h3 style="text-shadow: 5px 5px 5px grey">Current level : {{$users->level}} </h3>
        <br>        
        <div class="container">
            <div class="w3-border">
                @if($users->level == 1)
                    <div class="w3-green" style="height:24px;width:0%"> 0%  </div>
                @else
                    <div class="w3-green" style="height:24px;width:{{ ( $users->xp / floor(($users->level*(log10($users->level))*1000)) )* 100}}%">{{ round($users->xp / floor(($users->level*(log10($users->level))*1000)),5)* 100}}%  </div>
                @endif
            </div>
        </div>
        <h3 style="text-shadow: 5px 5px 5px grey">Current xp : {{$users->xp}}</h3>
        <br>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Email </h3>
        <p>{{$users->email}}</p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Age </h3>
        <p>{{$users->age}}</p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Gender </h3>
        <p>{{$users->gender}}</p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Token </h3>
        <p>{{$users->token}}</p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Working Status </h3>
        <p>{{$users->work_status}}</p>
    </div>
    <br>
    <div class="container">
        <h3 style="text-shadow: 5px 5px 5px grey">Tutor Pass </h3>
        <p>{{$users->pass}}</p>
    </div>
    @if(Auth::user()->pass != 'Active')
        <button style="background-color:#008CBA; color:whitesmoke; border:black 2px; border-radius: 10px; margin-left:5%; font-weight:bold; font-size:20px; padding:5px;"><a href="/profile/tutor"><i class="fa fa-male"></i> Tutor</a></button>
    @endif
    <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;" class="pull-right"><a href="/profile/edit"><i class="fa fa-edit"></i> Edit</a></button>
    <hr>
    <small style="font-weight:bold">Last Updated on: </small><small> {{$users->created_at}}</small>
    <br><br>
@endsection