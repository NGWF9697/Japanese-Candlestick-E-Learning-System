@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/profile"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br>
    <h3 style="text-shadow: 5px 5px 5px grey; text-align:center">{{$user->user_name}}</h3>
    {!! Form::open(['action' => ['ProfileController@update', $user->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('email', 'Email')}}
            {{Form::text('email', $user->email, ['class' => 'form-control', 'placeholder' => 'Title'])}}
        </div>
        <div class="form-group">
            {{Form::label('gender', 'Gender')}}
            {{Form::select('gender', array('Male'=>'Male', 'Female'=>'Female'), $user->gender, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('age', 'Age')}}
            {{Form::number('age', $user->age, ['class' => 'form-control', 'placeholder' => 'Age'])}}
        </div>
        <div class="form-group">
            {{Form::label('work_status', 'Work Status')}}
            {{Form::select('work_status', array('Yes'=>'Yes', 'No'=>'No'), $user->work_status, ['class' => 'form-control'])}}
        </div>
        {{Form::hidden('_method', 'PUT')}}
        {{Form::submit('Update', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
    <br>
    <hr>
    <small style="font-weight:bold">Last Updated on: </small><small> {{$user->created_at}}</small>
    <br><br>
@endsection