<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body {
                margin: 0;
                font-family: Arial, Helvetica, sans-serif;
            }
            .topnav {
                overflow: hidden;
                background-color: #333;
                transition-property: width;
                transition-duration: 2s;
            }

            .topnav a {
                float: left;
                display: block;
                color: #f2f2f2;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                font-size: 17px;
            }

            .topnav a:hover {
                background-color: #ddd;
                color: black;
            }

            .active {
                background-color: #4CAF50;
                color: white;
            }

            .topnav .icon {
                display: none;
            }
            #rightside{
                float:right;
            }


            @media screen and (max-width: 1080px) {
                .topnav a:not(:first-child) {display: none;}
                .topnav a.icon {
                    float: right;
                    display: block;
                }
            }

            @media screen and (max-width: 1080px) {
                #rightside{
                    float:none;
                }
                .topnav.responsive {position: relative;}
                .topnav.responsive .icon {
                    position: absolute;
                    right: 0;
                    top: 0;
                }
                .topnav.responsive a {
                    float: none;
                    display: block;
                    text-align: left;
                }
            }
        </style>
    </head>
    <body>
        <div class="topnav" id="myTopnav">
            <a href="/">JCS LEARNING</a>
            <a href="/about">About Us</a>
            <a href="/learn">Learn</a>
            <a href="/exercise">Exercises</a>
            <a href="{{action("ClassController@index")}}">Classes</a>
            <a href="/achievement">Achievement</a></li>
            <a href="/cs">Customer Service</a>
            @guest
                @if (Route::has('register'))
                    <a id="rightside" class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                @endif
                <a id="rightside" class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
            @else
                <a id="rightside" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    {{ __('Logout') }}
                </a>
                
                <a id="rightside" href="/profile">
                    <span>${{ Auth::user()->token }}</span> {{ Auth::user()->user_name }} <span>Lvl {{Auth::user()->level}} </span>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            @endguest

            <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <i class="fa fa-bars"></i>
            </a>
        </ul>
        </div>
    <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");            
            if (x.className === "topnav") {
                x.className += " responsive";x
            } else {
                x.className = "topnav";
            }
        }
        function highlightCurrent() {
            const curPage = document.URL;
            const links = document.getElementsByTagName('a');
            for (let link of links) {
                if (link.href == curPage) {
                    link.classList.add("active");
                }
            }
        }
        document.onreadystatechange = () => {
            if (document.readyState === 'complete') {
                highlightCurrent();
            }
        };
    </script>

    </body>
</html>
