@extends('layout.app1')
@section('header')
    <div id="bigdiv">
        <div class="container-fluid">
            <br>
            <button class="button1"><a href="/"><i class="fa fa-arrow-left"></i> Home </button></a>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-8 col-sm-12 col-xs-12">
                    <p style="color:whitesmoke; font-size:70px;text-align:center;font-style:italic;text-shadow:2px 2px green">JCS Learning </p><br>
                    <div class="form-contain">
                        <p id="customWord1">Login </p><br>
                        <div class="card-body">
                            <form method="POST" action="{{ route('login') }}">
                                @csrf
                                <div class="form-group row">
                                    <label for="user_name" id="customWord2">{{ __('User Name:') }}</label>

                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="user_name" type="text" class="form-control{{ $errors->has('user_name') ? ' is-invalid' : '' }}" name="user_name" value="{{ old('user_name') }}" required autofocus>
                                        @if ($errors->has('user_name'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('user_name') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password"id="customWord2">{{ __('Password:') }}</label>
                                    <div style="margin-left:auto; margin-right:auto; width:100%">
                                        <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                                        @if ($errors->has('password'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div style="text-align:center">
                                        <button type="submit" class="btn btn-primary" style="font-size:20px;">
                                            {{ __('Login') }}
                                        </button><br><br>
                                        <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px; opacity: 0.85;"><a href="/reset" style="font-style:italic;"><i class="fa fa-question-circle" style="font-size:36px"></i>  {{ __('Forgot Your Password?') }}</a></button>
                                        <br><br>
                                        <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px; opacity: 0.85;"><a href="/register" style="font-style:italic;"><i class="fa fa-male" style="font-size:30px"></i>  Register Now <i class="fa fa-female" style="font-size:30px"></i></a></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
@endsection