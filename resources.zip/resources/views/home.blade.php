@extends('layout.app')
@section('header')
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <div style="background-color:black">
        <div class="w3-content w3-display-container" style="width:100%">
            <img class="mySlides" src="http://www.kiplinger.com/kipimages/pages/13023.jpg" style="width:100%; height:500px;">
            <img class="mySlides" src="https://www.quantinsti.com/wp-content/uploads/2017/08/Statistical-arbitrage-Pair-trading-in-the-Mexican-stock-market_1.jpg" style="width:100%; height:500px;">
            <img class="mySlides" src="https://sslinvest.com/wp-content/uploads/2018/09/Market-Stock-Splits.jpg" style="width:100%; height:500px;">
            <img class="mySlides" src="https://www.xm.com/wp-content/uploads/2017/11/Stock-Charts-7-1.jpg" style="width:100%; height:500px;">
            <div class="w3-center w3-container w3-section w3-large w3-text-white w3-display-bottommiddle" style="width:70%">
                <div class="w3-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
                <div class="w3-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
                <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
                <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
                <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
                <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(4)"></span>
            </div>
        </div>
    </div>
    <script>
        var slideIndex = 1;
        showDivs(slideIndex);

        function plusDivs(n) {
            showDivs(slideIndex += n);
        }

        function currentDiv(n) {
            showDivs(slideIndex = n);
        }

        function showDivs(n) {
            var i;
            var x = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("demo");
            if (n > x.length) {slideIndex = 1}
            if (n < 1) {slideIndex = x.length}
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";  
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" w3-white", "");
            }
            x[slideIndex-1].style.display = "block";
            dots[slideIndex-1].className += " w3-white";
        }
    </script>
@endsection
@section('content')
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <div>
        @if(!Auth::guest())
            @if(Auth::user()->acc_type == 'Admin')
                <br>
                <button style="background-color:whitesmoke; border:none; font-weight:bold; font-size:24px;"><a href="/update/create"><i class="fa fa-edit"></i> Create New Updates </a></button>
                <br>
            @endif
        @endif
        <br>
        <div style="text-align:left; background-color:black">
                <button class="buttonedit tablink buttoneditcolor" onclick="switchtab(event,'Recent')">Recent</button>
                <button class="buttonedit tablink" onclick="switchtab(event,'Important')">Important</button>
                <button class="buttonedit tablink" onclick="switchtab(event,'General')">General</button>
            </div>
            @if(count($updates) > 0)
                <div id="Recent" class="con1 tab">
                    @if($recent = DB::table('updates')->where('type', '=', 'Recent')->get()->count() > 0)
                       @foreach($updates as $update)
                            @if($update->type == 'Recent')
                                <div class="well">
                                    <p style="font-style:italic; color:black; font-size:20px"><a href="/update/{{$update->id}}" id="writing">{{$update->title}}</a></p>
                                    <small style="font-weight:bold">Created at:</small><small> {{$update->created_at}}</small>
                                </div>
                            @endif
                        @endforeach
                    @else
                        <div class="well">
                            <p id="customWord2">No Recent Posts found</p>
                        </div>
                    @endif
                </div>
                <div id="Important" class="con1 tab" style="display:none">
                    @if($recent = DB::table('updates')->where('type', '=', 'Important')->get()->count() > 0)
                        @foreach($updates as $update)
                             @if($update->type == 'Important')
                                 <div class="well">
                                     <p style="font-style:italic; color:black; font-size:20px"><a href="/update/{{$update->id}}" id="writing">{{$update->title}}</a></p>
                                     <small style="font-weight:bold">Created at:</small><small> {{$update->created_at}}</small>
                                 </div>
                             @endif
                         @endforeach
                     @else
                         <div class="well">
                             <p id="customWord2">No Important Posts found</p>
                         </div>
                     @endif
                </div>
                <div id="General" class="con1 tab" style="display:none">
                    @if($recent = DB::table('updates')->where('type', '=', 'General')->get()->count() > 0)
                        @foreach($updates as $update)
                             @if($update->type == 'General')
                                 <div class="well">
                                     <p style="font-style:italic; color:black; font-size:20px"><a href="/update/{{$update->id}}" id="writing">{{$update->title}}</a></p>
                                     <small style="font-weight:bold">Created at:</small><small> {{$update->created_at}}</small>
                                 </div>
                             @endif
                         @endforeach
                     @else
                         <div class="well">
                             <p id="customWord2">No General Posts found</p>
                         </div>
                     @endif
                </div>
            @endif
            <br><br>
            <script>
                function switchtab(evt, tabname) {
                    var i, x, tablinks;
                    x = document.getElementsByClassName("con1");
                    for (i = 0; i < x.length; i++) {
                        x[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablink");
                    for (i = 0; i < x.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" buttoneditcolor", "");
                    }
                    document.getElementById(tabname).style.display = "block";
                    evt.currentTarget.className += " buttoneditcolor";
                }
            </script>
    </div>
@endsection
