@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none;"><a href="/learn"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br><br>
    <h1>Create Post</h1>
    <br>
        {!! Form::open(['action' => 'learnController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
            <div class="form-group">
                {{Form::label('title', 'Title')}}
                {{Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])}}
            </div>
            <div class="form-group">
                {{Form::label('picurl', 'Picture URL')}}
                {{Form::text('picurl', '', ['class' => 'form-control', 'placeholder' => 'URL'])}}
            </div>
            <div class="form-group">
                {{Form::label('desc', 'Description')}}
                {{Form::textarea('desc', '', ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])}}
            </div>
            <div class="form-group">
                {{Form::label('example', 'Example')}}
                {{Form::textarea('example', '', ['id' => 'ckeditor2', 'class' => 'form-control', 'placeholder' => 'Examples'])}}
            </div>
            {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        {!! Form::close() !!}
    <br>
@endsection