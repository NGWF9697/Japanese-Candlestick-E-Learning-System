@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none;"><a href="/learn"><i class="fa fa-arrow-left"></i> RETURN </a></button>
    <br>
    <br>
    <h1 id="customWord2">Edit Post</h1>
    {!! Form::open(['action' => ['learnController@update', $learn->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('title', 'Title')}}
            {{Form::text('title', $learn->title, ['class' => 'form-control', 'placeholder' => 'Title'])}}
        </div>
        <div class="form-group">
            {{Form::label('picurl', 'Picture URL')}}
            {{Form::text('picurl', $learn->picurl, ['class' => 'form-control', 'placeholder' => 'URL'])}}
        </div>
        <div class="form-group">
            {{Form::label('desc', 'Description')}}
            {{Form::textarea('desc', $learn->desc, ['id' => 'ckeditor1', 'class' => 'form-control', 'placeholder' => 'Body Text'])}}
        </div>
        <div class="form-group">
            {{Form::label('example', 'Example')}}
            {{Form::textarea('example', $learn->example, ['id' => 'ckeditor2', 'class' => 'form-control', 'placeholder' => 'Examples'])}}
        </div>
        {{Form::hidden('_method', 'PUT')}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
    <br>
@endsection