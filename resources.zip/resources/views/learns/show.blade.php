@extends('layout.app')
@section('content')
    <button style="background-color:whitesmoke; border:none; font-weight:bold;"><a href="/learn"><i class="fa fa-arrow-left"></i> RETURN</a></button>
    <br>
    <h1 style="text-shadow: 5px 5px 5px grey; text-align:center">{{$learn->title}}</h1>    
    <br>
    <div>
        <img src="{{$learn->picurl}}" style="display: block; margin-left: auto; margin-right: auto;">
    </div>
    <br>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Description</h1>
        <p>{!!$learn->desc!!}</p>
    </div>
    <hr>
    <div class="container">
        <h1 style="text-shadow: 5px 5px 5px grey">Examples</h1>
        <p>{!!$learn->example!!}</p>
    </div>
    <br>
    <small style="font-weight:bold">Last Updated on: </small><small> {{$learn->created_at}}</small>
    @if(!Auth::guest())
        @if(Auth::user()->acc_type == 'Admin')
            <br><br>
            <button style="background-color:whitesmoke; border:none; margin-left:5%; font-weight:bold; font-size:20px;"><a href="/learn/{{$learn->id}}/edit"><i class="fa fa-edit"></i> Edit</a></button>
            {!!Form::open(['action' => ['learnController@destroy', $learn->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
    <br><br>
@endsection