<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExercisesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('exercises', function (Blueprint $table) {
            $table->increments('id');
            $table->string('techniques');
            $table->string('questionnum');
            $table->string('question');
            $table->string('questiondesc');
            $table->string('qurl')->nullable();
            $table->string('ansA')->nullable();
            $table->string('ansB')->nullable();
            $table->string('ansC')->nullable();
            $table->string('ansD')->nullable();
            $table->string('ansE')->nullable();
            $table->string('correctans');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('exercises');
    }
}
