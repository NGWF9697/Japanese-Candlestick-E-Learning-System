<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTechniquesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('techniques', function (Blueprint $table) {
            $table->increments('id');
            $table->string('techniques');
            $table->string('status')->default('Incomplete');
            $table->timestamps();
        });

        $datas=['hammer','hanging_man','inverted_hammer','shooting_star',
        'doji_at_the_bottom','doji_at_the_top','bullish_meeting_line','bearish_meeting_line',
        'bullish_belt_hold_line','bearish_belt_hold_line','bullish_engulfing','bearish_engulfing','fred_tam’s_white_inside_out_up',
        'fred_tam’s_black_inside_out_down','piercing_line','dark_cloud_cover','bullish_harami_line','bearish_harami_line',
        'bullish_harami_cross','bearish_harami_cross','homing_pigeon','bearish_homing_pigeon','tweezers_bottom',
        'tweezers_top','star_at_the_bottom','star_at_the_top','river_morning_doji_star',
        'river_evening_doji_star','abandon_baby_bottom','abandon_baby_top','three-river_evening_star',
        'three-river_morning_star','tri-star_bottom','tri-star_top','breakaway_three_new_price_bottom',
        'breakaway_three_new_price_top','bullish_black_three-gaps','bearish_white_three-gaps','three_black_crows',
        'deliberation','upside_gap_two_crows','concealing_baby_swallow','ladder_bottom','tower_bottom','tower_top',
        'eight-to-ten_new_price_low','eight-to-ten_new_price_high','bullish_separating_line','bearish_separating_line','bullish_kicking_pattern',
        'bearish_kicking_pattern','on-neck_line','in-neck_line','thrusting_line', 'rising_three_methods','falling_three_method','mat_hold_pattern', 'tasuki_upside_gap','tasuki_downside_gap','upgap_side-by-side_white_lines',
        'downgap_side-by-side_white_lines','high-price_gapping_play','low-price_gapping_play'];

        foreach($datas as $data){
            DB::table('techniques')->insert(
                array(
                    'techniques' => $data,    
                )
            );
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('techniques');
    }
}
