<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('results', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('user_name');
            $table->string('quest1');
            $table->string('quest2');
            $table->string('quest3');
            $table->string('quest4');
            $table->string('quest5');
            $table->string('quest6');
            $table->string('quest7');
            $table->string('quest8');
            $table->string('quest9');
            $table->string('quest10');
            $table->string('quest1desc');
            $table->string('quest2desc');
            $table->string('quest3desc');
            $table->string('quest4desc');
            $table->string('quest5desc');
            $table->string('quest6desc');
            $table->string('quest7desc');
            $table->string('quest8desc');
            $table->string('quest9desc');
            $table->string('quest10desc');
            $table->integer('num_correct');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('results');
    }
}
