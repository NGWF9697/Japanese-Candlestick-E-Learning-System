$(function(){
    //variable
    var maxrow = 5;
    
    var count = 1;
    var x;
    //add
    $("#add").on("click",function(){
        if(count<maxrow){
            x = document.getElementById('lecture'+count);
            x.childNodes[3].disabled=false;
            x.childNodes[9].disabled=false;
            CKEDITOR.instances['youtubedesc'+count].setReadOnly(false);
            x.style.display = "block";
            count++;
        }
    });

    $("#remove").on("click",function(){
        if(count!=1){
            count--;
            x = document.getElementById('lecture'+count);
            x.childNodes[3].disabled=true;
            x.childNodes[9].disabled=true;
            CKEDITOR.instances['youtubedesc'+count].setReadOnly(true);
            x.style.display = "none"; 
        }
     });
});