<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::resource('classes','PostsController',[
    'only'=>[
        'store'
    ]
]);

Route::get('Class/lecture/{data}', 'ClassController@lecture')->name("Class.lecture");
Route::get('Class/myclass/', 'ClassController@myclass')->name("Class.myclass");
Route::post('Class/search/', 'ClassController@search')->name("Class.search");
Route::get('Class/joinclass', 'ClassController@joinclass')->name("Class.joinclass");
Route::resource('Class','ClassController',[
    'name'=>[
        'index' => 'class',
        'store' => 'class.store'
    ],
    'only'=>[
        'show','store','index','create','destroy','update'
    ]
]);

Route::get('/about', 'PagesController@about');
Route::get('/', 'HomeController@index');
Route::get('/profile/edit', 'ProfileController@edit');
Route::get('/profile/tutor', 'tutorController@edit');
Route::resource('update', 'UpdateController');
Route::resource('cs', 'CSController');
Route::resource('learn', 'learnController');
Route::resource('achievement', 'AchieveController');
Route::resource('profile', 'ProfileController');
Route::resource('tutor', 'tutorController');
Route::resource('exercise', 'ExerciseController');
Route::resource('quiz', 'QuizController');
Route::resource('reset', 'resetController');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

//general
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
